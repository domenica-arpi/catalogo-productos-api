# -*- coding: utf-8 -*-
"""
CinePlus - Analisis de control
Reproduce en Python los resultados de los 3 reportes de Power BI.
Sirve para contrastar que el modelo DAX devuelve las mismas cifras.

Salida: consola + docs/hallazgos.md
"""

import csv
import os
from collections import defaultdict

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
D = os.path.join(BASE, "datos")


def leer(nombre):
    with open(os.path.join(D, nombre), encoding="utf-8-sig") as f:
        return list(csv.DictReader(f, delimiter=";"))


pais = {r["PaisID"]: r for r in leer("DimPais.csv")}
genero = {r["GeneroID"]: r for r in leer("DimGenero.csv")}
disp = {r["DispositivoID"]: r for r in leer("DimDispositivo.csv")}
cont = {r["ContenidoID"]: r for r in leer("DimContenido.csv")}
hora = {r["HoraKey"]: r for r in leer("DimHora.csv")}
tiempo = {r["FechaKey"]: r for r in leer("DimTiempo.csv")}
hechos = leer("FactVisualizaciones.csv")

OUT = []


def p(s=""):
    print(s)
    OUT.append(s)


def pct(a, b):
    return f"{100.0*a/b:.1f}%" if b else "n/d"


def miles(n):
    return f"{n:,}".replace(",", ".")


N = len(hechos)
minutos = sum(int(h["MinutosVistos"]) for h in hechos)
usuarios = len({h["UsuarioID"] for h in hechos})
completadas = sum(int(h["Completado"]) for h in hechos)
prime = sum(int(h["EsPrimeTime"]) for h in hechos)
vals = [int(h["Valoracion"]) for h in hechos if h["Valoracion"]]

p("# Hallazgos del analisis — CinePlus")
p()
p("Cifras calculadas directamente sobre `datos/FactVisualizaciones.csv`.")
p("Deben coincidir exactamente con las medidas DAX del modelo.")
p()
p("## Indicadores globales")
p()
p("| Indicador | Valor |")
p("|---|---|")
p(f"| Total visualizaciones | {miles(N)} |")
p(f"| Usuarios unicos | {miles(usuarios)} |")
p(f"| Contenidos reproducidos | {len({h['ContenidoID'] for h in hechos})} |")
p(f"| Minutos vistos | {miles(minutos)} |")
p(f"| Horas vistas | {miles(minutos//60)} |")
p(f"| Promedio min. por sesion | {minutos/N:.1f} |")
p(f"| % completitud | {pct(completadas, N)} |")
p(f"| % prime time | {pct(prime, N)} |")
p(f"| Valoracion promedio | {sum(vals)/len(vals):.2f} ({miles(len(vals))} sesiones valoradas) |")
p()

# ------------------------------------------------- REPORTE 1
p("## Reporte 1 — Visualizaciones por pais y genero")
p()
por_pais = defaultdict(int)
min_pais = defaultdict(int)
for h in hechos:
    por_pais[h["PaisID"]] += 1
    min_pais[h["PaisID"]] += int(h["MinutosVistos"])

p("| Pais | Region | Visualizaciones | % | Horas vistas |")
p("|---|---|---:|---:|---:|")
for pid, n in sorted(por_pais.items(), key=lambda x: -x[1]):
    r = pais[pid]
    p(f"| {r['Pais']} | {r['Region']} | {miles(n)} | {pct(n, N)} | {miles(min_pais[pid]//60)} |")
p()

por_gen = defaultdict(int)
for h in hechos:
    por_gen[cont[h["ContenidoID"]]["GeneroID"]] += 1
p("| Genero | Visualizaciones | % |")
p("|---|---:|---:|")
for gid, n in sorted(por_gen.items(), key=lambda x: -x[1]):
    p(f"| {genero[gid]['Genero']} | {miles(n)} | {pct(n, N)} |")
p()

# genero lider por pais
cruce = defaultdict(lambda: defaultdict(int))
for h in hechos:
    cruce[h["PaisID"]][cont[h["ContenidoID"]]["GeneroID"]] += 1
p("**Genero lider en cada pais** (lo que el grafico de barras por si solo no revela):")
p()
p("| Pais | Genero lider | Visualizaciones | Cuota dentro del pais |")
p("|---|---|---:|---:|")
for pid, n in sorted(por_pais.items(), key=lambda x: -x[1]):
    gid, c = max(cruce[pid].items(), key=lambda x: x[1])
    p(f"| {pais[pid]['Pais']} | {genero[gid]['Genero']} | {miles(c)} | {pct(c, n)} |")
p()

# ------------------------------------------------- REPORTE 2
p("## Reporte 2 — Top 10 contenidos mas vistos")
p()
por_cont = defaultdict(int)
min_cont = defaultdict(int)
comp_cont = defaultdict(int)
for h in hechos:
    c = h["ContenidoID"]
    por_cont[c] += 1
    min_cont[c] += int(h["MinutosVistos"])
    comp_cont[c] += int(h["Completado"])

top = sorted(por_cont.items(), key=lambda x: -x[1])
p("| # | Titulo | Genero | Tipo | Visualizaciones | Horas | % completitud |")
p("|---:|---|---|---|---:|---:|---:|")
for i, (cid, n) in enumerate(top[:10], 1):
    c = cont[cid]
    p(f"| {i} | {c['Titulo']} | {genero[c['GeneroID']]['Genero']} | {c['TipoContenido']} "
      f"| {miles(n)} | {miles(min_cont[cid]//60)} | {pct(comp_cont[cid], n)} |")
p()
top10 = sum(n for _, n in top[:10])
p(f"El Top 10 concentra **{miles(top10)} visualizaciones**, el **{pct(top10, N)}** del consumo "
  f"total, sobre un catalogo de {len(cont)} titulos. "
  f"Los 10 titulos de la cola suman {miles(sum(n for _, n in top[-10:]))}.")
p()

# ------------------------------------------------- REPORTE 3
p("## Reporte 3 — Dispositivos en horario prime (19:00–22:59)")
p()
dp = defaultdict(int)
dnp = defaultdict(int)
dmin = defaultdict(int)
for h in hechos:
    if int(h["EsPrimeTime"]):
        dp[h["DispositivoID"]] += 1
        dmin[h["DispositivoID"]] += int(h["MinutosVistos"])
    else:
        dnp[h["DispositivoID"]] += 1

p("| Dispositivo | Tipo | Prime time | % del prime | Fuera de prime | Indice prime |")
p("|---|---|---:|---:|---:|---:|")
for did, n in sorted(dp.items(), key=lambda x: -x[1]):
    d = disp[did]
    cuota_prime = n / prime
    cuota_resto = dnp[did] / (N - prime)
    p(f"| {d['Dispositivo']} | {d['TipoDispositivo']} | {miles(n)} | {pct(n, prime)} "
      f"| {miles(dnp[did])} | {cuota_prime/cuota_resto:.2f} |")
p()
p("*Indice prime = cuota del dispositivo dentro del horario estelar dividida por su "
  "cuota fuera de el. Mayor que 1 significa sobre-representado en prime time.*")
p()

por_hora = defaultdict(int)
for h in hechos:
    por_hora[h["HoraKey"]] += 1
pico = max(por_hora.items(), key=lambda x: x[1])
valle = min(por_hora.items(), key=lambda x: x[1])
p(f"Hora pico: **{hora[pico[0]]['Hora']}** con {miles(pico[1])} visualizaciones. "
  f"Hora valle: **{hora[valle[0]]['Hora']}** con {miles(valle[1])}. "
  f"La franja prime concentra el **{pct(prime, N)}** del consumo en solo 4 de las 24 horas "
  f"(seria {100*4/24:.1f}% si el consumo se repartiera de forma uniforme).")
p()

franja = defaultdict(int)
for h in hechos:
    franja[hora[h["HoraKey"]]["FranjaHoraria"]] += 1
p("| Franja | Visualizaciones | % |")
p("|---|---:|---:|")
for f, n in sorted(franja.items(), key=lambda x: -x[1]):
    p(f"| {f} | {miles(n)} | {pct(n, N)} |")
p()

# ------------------------------------------------- ESTACIONALIDAD
p("## Estacionalidad mensual (dashboard)")
p()
mes = defaultdict(int)
for h in hechos:
    t = tiempo[h["FechaKey"]]
    mes[(int(t["NumeroMes"]), t["Mes"])] += 1
p("| Mes | Visualizaciones | % |")
p("|---|---:|---:|")
for (nm, nombre), n in sorted(mes.items()):
    p(f"| {nombre} | {miles(n)} | {pct(n, N)} |")
p()
mx = max(mes.items(), key=lambda x: x[1])
mn = min(mes.items(), key=lambda x: x[1])
p(f"Pico en **{mx[0][1]}** ({miles(mx[1])}) y minimo en **{mn[0][1]}** ({miles(mn[1])}): "
  f"una amplitud del {100*(mx[1]-mn[1])/mn[1]:.0f}% entre el mejor y el peor mes.")
p()

tipo_dia = defaultdict(int)
dias = defaultdict(int)
for h in hechos:
    t = tiempo[h["FechaKey"]]
    tipo_dia[t["TipoDia"]] += 1
    dias[t["TipoDia"]] = dias[t["TipoDia"]]
n_finde = sum(1 for t in tiempo.values() if t["TipoDia"] == "Fin de Semana")
n_semana = len(tiempo) - n_finde
p(f"Fin de semana: {miles(tipo_dia['Fin de Semana'])} visualizaciones en {n_finde} dias "
  f"({tipo_dia['Fin de Semana']/n_finde:,.0f} por dia). "
  f"Entre semana: {miles(tipo_dia['Entre Semana'])} en {n_semana} dias "
  f"({tipo_dia['Entre Semana']/n_semana:,.0f} por dia).")

ruta = os.path.join(BASE, "docs", "hallazgos.md")
os.makedirs(os.path.dirname(ruta), exist_ok=True)
with open(ruta, "w", encoding="utf-8") as f:
    f.write("\n".join(OUT) + "\n")
print(f"\n\n[guardado en {ruta}]")
