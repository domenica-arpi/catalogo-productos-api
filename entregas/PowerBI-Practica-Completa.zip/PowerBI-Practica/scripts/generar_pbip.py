# -*- coding: utf-8 -*-
"""
CinePlus - Generador del proyecto Power BI (formato PBIP)
Practica Power BI + SSAS  |  Estudiante: Andy Chafla

Construye:
  pbip/CinePlus.pbip
  pbip/CinePlus.SemanticModel/   -> modelo semantico en TMDL (replica del cubo)
  pbip/CinePlus.Report/          -> reporte en PBIR (4 paginas)

Todos los JSON se validan contra los esquemas oficiales de Microsoft
(ver scripts/validar_pbip.py).
"""

import json
import os
import shutil
import uuid

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PBIP = os.path.join(BASE, "pbip")
SM = os.path.join(PBIP, "CinePlus.SemanticModel")
RP = os.path.join(PBIP, "CinePlus.Report")
DATOS = os.path.join(BASE, "datos")

NS = uuid.UUID("7f3c1e22-9a4b-4d6e-8f10-c1e40b500001")
def gid(s):
    return str(uuid.uuid5(NS, s))

def w(path, contenido):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(contenido)

def wj(path, obj):
    w(path, json.dumps(obj, indent=2, ensure_ascii=False) + "\n")

if os.path.isdir(PBIP):
    shutil.rmtree(PBIP)

SCH = "https://developer.microsoft.com/json-schemas/fabric"

# =====================================================================
#  1. MODELO SEMANTICO (TMDL)
# =====================================================================

# nombre, tipo_tmdl, tipo_m, formatString, oculta
TABLAS = {
    "DimPais": [
        ("PaisID",    "int64",  "Int64.Type", "0", True),
        ("Pais",      "string", "type text",  None, False),
        ("CodigoISO", "string", "type text",  None, False),
        ("Region",    "string", "type text",  None, False),
        ("Moneda",    "string", "type text",  None, False),
    ],
    "DimGenero": [
        ("GeneroID",        "int64",  "Int64.Type", "0", True),
        ("Genero",          "string", "type text",  None, False),
        ("CategoriaGenero", "string", "type text",  None, False),
    ],
    "DimDispositivo": [
        ("DispositivoID",    "int64",  "Int64.Type", "0", True),
        ("Dispositivo",      "string", "type text",  None, False),
        ("TipoDispositivo",  "string", "type text",  None, False),
        ("SistemaOperativo", "string", "type text",  None, False),
        ("TamanoPantalla",   "string", "type text",  None, False),
    ],
    "DimContenido": [
        ("ContenidoID",    "int64",  "Int64.Type", "0", True),
        ("Titulo",         "string", "type text",  None, False),
        ("GeneroID",       "int64",  "Int64.Type", "0", True),
        ("TipoContenido",  "string", "type text",  None, False),
        ("AnioEstreno",    "int64",  "Int64.Type", "0", False),
        ("DuracionMin",    "int64",  "Int64.Type", "#,0", False),
        ("Temporadas",     "int64",  "Int64.Type", "0", False),
        ("Episodios",      "int64",  "Int64.Type", "0", False),
        ("Clasificacion",  "string", "type text",  None, False),
        ("OrigenContenido","string", "type text",  None, False),
    ],
    "DimUsuario": [
        ("UsuarioID",     "int64",  "Int64.Type", "0", True),
        ("CodigoUsuario", "string", "type text",  None, False),
        ("PaisID",        "int64",  "Int64.Type", "0", True),
        ("TipoPlan",      "string", "type text",  None, False),
        ("Edad",          "int64",  "Int64.Type", "0", False),
        ("RangoEtario",   "string", "type text",  None, False),
        ("Genero",        "string", "type text",  None, False),
        ("FechaRegistro", "dateTime", "type date", "Short Date", False),
        ("EstadoCuenta",  "string", "type text",  None, False),
    ],
    "DimTiempo": [
        ("FechaKey",      "int64",  "Int64.Type", "0", True),
        ("Fecha",         "dateTime", "type date", "Short Date", False),
        ("Anio",          "int64",  "Int64.Type", "0", False),
        ("Trimestre",     "string", "type text",  None, False),
        ("AnioTrimestre", "string", "type text",  None, False),
        ("NumeroMes",     "int64",  "Int64.Type", "0", True),
        ("Mes",           "string", "type text",  None, False),
        ("AnioMes",       "string", "type text",  None, False),
        ("Dia",           "int64",  "Int64.Type", "0", False),
        ("NombreDia",     "string", "type text",  None, False),
        ("NumeroDia",     "int64",  "Int64.Type", "0", True),
        ("SemanaAnio",    "int64",  "Int64.Type", "0", False),
        ("TipoDia",       "string", "type text",  None, False),
    ],
    "DimHora": [
        ("HoraKey",       "int64",  "Int64.Type", "0", False),
        ("Hora",          "string", "type text",  None, False),
        ("FranjaHoraria", "string", "type text",  None, False),
        ("OrdenFranja",   "int64",  "Int64.Type", "0", True),
        ("EsPrimeTime",   "int64",  "Int64.Type", "0", True),
        ("PrimeTimeDesc", "string", "type text",  None, False),
        ("RangoHora",     "string", "type text",  None, False),
    ],
    "FactVisualizaciones": [
        ("VisualizacionID", "int64",  "Int64.Type", "0", True),
        ("FechaKey",        "int64",  "Int64.Type", "0", True),
        ("HoraKey",         "int64",  "Int64.Type", "0", True),
        ("UsuarioID",       "int64",  "Int64.Type", "0", True),
        ("ContenidoID",     "int64",  "Int64.Type", "0", True),
        ("DispositivoID",   "int64",  "Int64.Type", "0", True),
        ("PaisID",          "int64",  "Int64.Type", "0", True),
        ("GeneroID",        "int64",  "Int64.Type", "0", True),
        ("MinutosVistos",   "int64",  "Int64.Type", "#,0", True),
        ("PorcentajeVisto", "double", "type number", "0.00", True),
        ("Completado",      "int64",  "Int64.Type", "0", True),
        ("EsPrimeTime",     "int64",  "Int64.Type", "0", True),
        ("Reproducciones",  "int64",  "Int64.Type", "0", True),
        ("Valoracion",      "int64",  "Int64.Type", "0", True),
    ],
}

# columna de ordenamiento: evita ejes alfabeticos (Abril antes que Enero)
SORT_BY = {
    ("DimTiempo", "Mes"): "NumeroMes",
    ("DimTiempo", "NombreDia"): "NumeroDia",
    ("DimHora", "FranjaHoraria"): "OrdenFranja",
}

DESCRIPCIONES = {
    "DimPais": "Dimension geografica. Equivale a la dimension [Pais] del cubo CinePlus_Cubo.",
    "DimGenero": "Dimension de generos audiovisuales. Equivale a [Genero] del cubo.",
    "DimDispositivo": "Dimension de dispositivos de reproduccion. Equivale a [Dispositivo] del cubo.",
    "DimContenido": "Dimension de catalogo (peliculas y series). Equivale a [Contenido] del cubo.",
    "DimUsuario": "Dimension de suscriptores. Equivale a [Usuario] del cubo.",
    "DimTiempo": "Dimension de tiempo a nivel dia. Equivale a [Tiempo] del cubo.",
    "DimHora": "Dimension de franja horaria. Soporta el analisis de horario prime time.",
    "FactVisualizaciones": "Tabla de hechos: una fila por reproduccion. Grupo de medida [Visualizaciones] del cubo.",
}


def tmdl_tabla(nombre, cols):
    n_cols = len(cols)
    tipos = ", ".join(f'{{"{c[0]}", {c[2]}}}' for c in cols)
    L = []
    L.append(f"table {nombre}")
    L.append(f"\tlineageTag: {gid('t:'+nombre)}")
    L.append(f"\tdescription: {DESCRIPCIONES[nombre]}")
    L.append("")
    for nom, dt, mt, fmt, oculta in cols:
        L.append(f"\tcolumn {nom}")
        L.append(f"\t\tdataType: {dt}")
        if oculta:
            L.append("\t\tisHidden")
        if fmt:
            L.append(f'\t\tformatString: {fmt}')
        L.append(f"\t\tlineageTag: {gid('c:'+nombre+'.'+nom)}")
        L.append("\t\tsummarizeBy: none")
        L.append(f"\t\tsourceColumn: {nom}")
        if (nombre, nom) in SORT_BY:
            L.append(f"\t\tsortByColumn: {SORT_BY[(nombre, nom)]}")
        L.append("")
        L.append("\t\tannotation SummarizationSetBy = Automatic")
        if dt == "dateTime":
            L.append("")
            L.append('\t\tannotation UnderlyingDateTimeDataType = Date')
        L.append("")

    # jerarquias
    if nombre == "DimTiempo":
        L += [
            "\thierarchy 'Jerarquia Calendario'",
            f"\t\tlineageTag: {gid('h:cal')}",
            "",
            "\t\tlevel Anio",
            f"\t\t\tlineageTag: {gid('h:cal.anio')}",
            "\t\t\tcolumn: Anio",
            "",
            "\t\tlevel Trimestre",
            f"\t\t\tlineageTag: {gid('h:cal.tri')}",
            "\t\t\tcolumn: Trimestre",
            "",
            "\t\tlevel Mes",
            f"\t\t\tlineageTag: {gid('h:cal.mes')}",
            "\t\t\tcolumn: Mes",
            "",
            "\t\tlevel Dia",
            f"\t\t\tlineageTag: {gid('h:cal.dia')}",
            "\t\t\tcolumn: Dia",
            "",
        ]
    if nombre == "DimPais":
        L += [
            "\thierarchy 'Jerarquia Geografica'",
            f"\t\tlineageTag: {gid('h:geo')}",
            "",
            "\t\tlevel Region",
            f"\t\t\tlineageTag: {gid('h:geo.reg')}",
            "\t\t\tcolumn: Region",
            "",
            "\t\tlevel Pais",
            f"\t\t\tlineageTag: {gid('h:geo.pais')}",
            "\t\t\tcolumn: Pais",
            "",
        ]
    if nombre == "DimContenido":
        L += [
            "\thierarchy 'Jerarquia Catalogo'",
            f"\t\tlineageTag: {gid('h:cat')}",
            "",
            "\t\tlevel TipoContenido",
            f"\t\t\tlineageTag: {gid('h:cat.tipo')}",
            "\t\t\tcolumn: TipoContenido",
            "",
            "\t\tlevel Titulo",
            f"\t\t\tlineageTag: {gid('h:cat.tit')}",
            "\t\t\tcolumn: Titulo",
            "",
        ]

    L.append(f"\tpartition {nombre} = m")
    L.append("\t\tmode: import")
    L.append("\t\tsource =")
    L.append("\t\t\t\tlet")
    L.append(f'\t\t\t\t    Origen = Csv.Document(File.Contents(RutaDatos & "{nombre}.csv"), '
             f'[Delimiter=";", Columns={n_cols}, Encoding=65001, QuoteStyle=QuoteStyle.Csv]),')
    L.append("\t\t\t\t    Encabezados = Table.PromoteHeaders(Origen, [PromoteAllScalars=true]),")
    L.append(f'\t\t\t\t    Tipos = Table.TransformColumnTypes(Encabezados, {{{tipos}}}, "en-US")')
    L.append("\t\t\t\tin")
    L.append("\t\t\t\t    Tipos")
    L.append("")
    L.append("\tannotation PBI_ResultType = Table")
    L.append("")
    return "\n".join(L)


for t, cols in TABLAS.items():
    w(os.path.join(SM, "definition", "tables", f"{t}.tmdl"), tmdl_tabla(t, cols))

# ---------------------------------------------------------- MEDIDAS DAX
MEDIDAS = [
    ("Total Visualizaciones", "COUNTROWS ( FactVisualizaciones )", "#,0",
     "01 Volumen", "Numero total de reproducciones registradas."),
    ("Usuarios Unicos", "DISTINCTCOUNT ( FactVisualizaciones[UsuarioID] )", "#,0",
     "01 Volumen", "Suscriptores distintos con al menos una reproduccion."),
    ("Contenidos Unicos", "DISTINCTCOUNT ( FactVisualizaciones[ContenidoID] )", "#,0",
     "01 Volumen", "Titulos distintos reproducidos."),
    ("Visualizaciones por Usuario",
     "DIVIDE ( [Total Visualizaciones], [Usuarios Unicos] )", "#,0.0",
     "01 Volumen", "Intensidad de consumo por suscriptor."),

    ("Minutos Vistos", "SUM ( FactVisualizaciones[MinutosVistos] )", "#,0",
     "02 Consumo", "Suma de minutos efectivamente reproducidos."),
    ("Horas Vistas", "DIVIDE ( [Minutos Vistos], 60 )", "#,0",
     "02 Consumo", "Minutos vistos expresados en horas."),
    ("Promedio Minutos por Visualizacion",
     "DIVIDE ( [Minutos Vistos], [Total Visualizaciones] )", "#,0.0",
     "02 Consumo", "Duracion media de una sesion de reproduccion."),

    ("Visualizaciones Completadas",
     "CALCULATE ( [Total Visualizaciones], FactVisualizaciones[Completado] = 1 )", "#,0",
     "03 Calidad", "Reproducciones con 85% o mas del contenido visto."),
    ("% Completitud",
     "DIVIDE ( [Visualizaciones Completadas], [Total Visualizaciones] )", "0.0%",
     "03 Calidad", "Porcentaje de sesiones terminadas. KPI de retencion."),
    ("Valoracion Promedio",
     "AVERAGE ( FactVisualizaciones[Valoracion] )", "0.00",
     "03 Calidad", "Calificacion media (1 a 5) sobre las sesiones valoradas."),
    ("% Avance Promedio",
     "AVERAGE ( FactVisualizaciones[PorcentajeVisto] ) / 100", "0.0%",
     "03 Calidad", "Porcentaje medio del contenido consumido por sesion."),

    ("Visualizaciones Prime Time",
     "CALCULATE ( [Total Visualizaciones], DimHora[EsPrimeTime] = 1 )", "#,0",
     "04 Prime Time", "Reproducciones entre las 19:00 y las 22:59."),
    ("Visualizaciones Fuera de Prime",
     "CALCULATE ( [Total Visualizaciones], DimHora[EsPrimeTime] = 0 )", "#,0",
     "04 Prime Time", "Reproducciones fuera del horario estelar."),
    ("% Prime Time",
     "DIVIDE ( [Visualizaciones Prime Time], [Total Visualizaciones] )", "0.0%",
     "04 Prime Time", "Concentracion del consumo en horario estelar."),
    ("Horas Prime Time",
     "CALCULATE ( [Horas Vistas], DimHora[EsPrimeTime] = 1 )", "#,0",
     "04 Prime Time", "Horas consumidas en horario estelar."),
    ("Dispositivo Lider Prime",
     "VAR _t =\n"
     "    TOPN (\n"
     "        1,\n"
     "        VALUES ( DimDispositivo[Dispositivo] ),\n"
     "        [Visualizaciones Prime Time], DESC\n"
     "    )\n"
     "RETURN\n"
     "    CONCATENATEX ( _t, DimDispositivo[Dispositivo], \", \" )", None,
     "04 Prime Time", "Dispositivo con mayor consumo en prime time."),

    ("Ranking Contenido",
     "IF (\n"
     "    NOT ISBLANK ( [Total Visualizaciones] ),\n"
     "    RANKX (\n"
     "        ALLSELECTED ( DimContenido[Titulo] ),\n"
     "        [Total Visualizaciones], , DESC, DENSE\n"
     "    )\n"
     ")", "0",
     "05 Ranking", "Posicion del titulo por numero de reproducciones."),
    ("Top 10 Contenidos",
     "IF ( [Ranking Contenido] <= 10, [Total Visualizaciones] )", "#,0",
     "05 Ranking", "Visualizaciones, solo para los 10 titulos mas vistos."),
    ("Contenido Mas Visto",
     "VAR _t =\n"
     "    TOPN ( 1, VALUES ( DimContenido[Titulo] ), [Total Visualizaciones], DESC )\n"
     "RETURN\n"
     "    CONCATENATEX ( _t, DimContenido[Titulo], \", \" )", None,
     "05 Ranking", "Titulo numero 1 del ranking en el contexto actual."),

    ("Visualizaciones Mes Anterior",
     "CALCULATE (\n"
     "    [Total Visualizaciones],\n"
     "    DATEADD ( DimTiempo[Fecha], -1, MONTH )\n"
     ")", "#,0",
     "06 Tiempo", "Mismo indicador desplazado un mes."),
    ("% Variacion Mensual",
     "VAR _ant = [Visualizaciones Mes Anterior]\n"
     "RETURN\n"
     "    DIVIDE ( [Total Visualizaciones] - _ant, _ant )", "+0.0%;-0.0%;0.0%",
     "06 Tiempo", "Crecimiento respecto del mes previo."),
]


def tmdl_medidas():
    L = ["table _Medidas",
         f"\tlineageTag: {gid('t:_Medidas')}",
         "\tdescription: Tabla contenedora de los indicadores calculados (medidas DAX).",
         ""]
    for nom, dax, fmt, carpeta, desc in MEDIDAS:
        L.append(f"\tmeasure '{nom}' =")
        for ln in dax.split("\n"):
            L.append(f"\t\t\t{ln}")
        if fmt:
            L.append(f"\t\tformatString: {fmt}")
        L.append(f"\t\tlineageTag: {gid('m:'+nom)}")
        L.append(f"\t\tdisplayFolder: {carpeta}")
        L.append(f"\t\tdescription: {desc}")
        L.append("")
    L += [
        "\tcolumn _",
        "\t\tdataType: string",
        "\t\tisHidden",
        f"\t\tlineageTag: {gid('c:_Medidas._')}",
        "\t\tsummarizeBy: none",
        "\t\tsourceColumn: _",
        "",
        "\t\tannotation SummarizationSetBy = Automatic",
        "",
        "\tpartition _Medidas = m",
        "\t\tmode: import",
        "\t\tsource =",
        "\t\t\t\tlet",
        "\t\t\t\t    Origen = #table(type table [_ = text], {})",
        "\t\t\t\tin",
        "\t\t\t\t    Origen",
        "",
        "\tannotation PBI_ResultType = Table",
        "",
    ]
    return "\n".join(L)


w(os.path.join(SM, "definition", "tables", "_Medidas.tmdl"), tmdl_medidas())

# ------------------------------------------------------------ PARAMETRO
ruta = DATOS.replace("/", "\\") + "\\"
w(os.path.join(SM, "definition", "expressions.tmdl"),
  "expression RutaDatos = \"" + ruta + "\" meta [IsParameterQuery=true, Type=\"Text\", "
  "IsParameterQueryRequired=true]\n"
  f"\tlineageTag: {gid('e:RutaDatos')}\n"
  "\tqueryGroup: Parametros\n"
  "\tdescription: Carpeta que contiene los CSV del Data Warehouse CinePlus.\n"
  "\n"
  "\tannotation PBI_NavigationStepName = Navigation\n"
  "\n"
  "\tannotation PBI_ResultType = Text\n"
  "\n"
  "queryGroup Parametros\n"
  "\n"
  "\tannotation PBI_QueryGroupOrder = 0\n")

# -------------------------------------------------------- RELACIONES
RELACIONES = [
    ("FactVisualizaciones.FechaKey",      "DimTiempo.FechaKey",      True),
    ("FactVisualizaciones.HoraKey",       "DimHora.HoraKey",         True),
    ("FactVisualizaciones.UsuarioID",     "DimUsuario.UsuarioID",    True),
    ("FactVisualizaciones.ContenidoID",   "DimContenido.ContenidoID",True),
    ("FactVisualizaciones.DispositivoID", "DimDispositivo.DispositivoID", True),
    ("FactVisualizaciones.PaisID",        "DimPais.PaisID",          True),
    ("DimContenido.GeneroID",             "DimGenero.GeneroID",      True),
    # Inactiva a proposito: evita ambiguedad con Fact -> DimPais
    ("DimUsuario.PaisID",                 "DimPais.PaisID",          False),
]
rel = []
for f, t, activa in RELACIONES:
    rel.append(f"relationship {gid('r:'+f+'>'+t)}")
    if not activa:
        rel.append("\tisActive: false")
    rel.append(f"\tfromColumn: {f}")
    rel.append(f"\ttoColumn: {t}")
    rel.append("")
w(os.path.join(SM, "definition", "relationships.tmdl"), "\n".join(rel))

# ------------------------------------------------------------- MODELO
orden = ["DimPais", "DimGenero", "DimDispositivo", "DimContenido", "DimUsuario",
         "DimTiempo", "DimHora", "FactVisualizaciones", "_Medidas"]
modelo = [
    "model Model",
    "\tculture: es-ES",
    "\tdefaultPowerBIDataSourceVersion: powerBI_V3",
    "\tdiscourageImplicitMeasures",
    "\tsourceQueryCulture: es-ES",
    "\tdataAccessOptions",
    "\t\tlegacyRedirects",
    "\t\treturnErrorValuesAsNull",
    "",
    "annotation PBI_QueryOrder = " + json.dumps(orden + ["RutaDatos"]),
    "",
    "annotation __PBI_TimeIntelligenceEnabled = 0",
    "",
    "annotation PBIDesktopVersion = 2.159.1231.0 (26.09)",
    "",
]
for t in orden:
    modelo.append(f"ref table {t}")
    modelo.append("")
modelo.append("ref expression RutaDatos")
modelo.append("")
w(os.path.join(SM, "definition", "model.tmdl"), "\n".join(modelo))

w(os.path.join(SM, "definition", "database.tmdl"),
  "database CinePlus\n\tcompatibilityLevel: 1567\n")

wj(os.path.join(SM, "definition.pbism"),
   {"$schema": f"{SCH}/item/semanticModel/definitionProperties/1.0.0/schema.json",
    "version": "4.2",
    "settings": {}})

wj(os.path.join(SM, ".platform"),
   {"$schema": f"{SCH}/gitIntegration/platformProperties/2.0.0/schema.json",
    "metadata": {"type": "SemanticModel", "displayName": "CinePlus"},
    "config": {"version": "2.0", "logicalId": gid("logical:sm")}})

# diagrama del modelo: estrella con la tabla de hechos al centro
pos = {
    "FactVisualizaciones": (520, 300), "DimTiempo": (180, 90), "DimHora": (520, 60),
    "DimPais": (880, 90), "DimContenido": (880, 300), "DimGenero": (1180, 300),
    "DimDispositivo": (880, 520), "DimUsuario": (180, 420), "_Medidas": (180, 620),
}
wj(os.path.join(SM, "diagramLayout.json"), {
    "version": "1.1.0",
    "diagrams": [{
        "ordinal": 0, "scrollPosition": {"x": 0, "y": 0}, "nodes": [
            {"location": {"x": x, "y": y}, "nodeIndex": t,
             "nodeLineageTag": gid("t:" + t), "size": {"height": 200, "width": 230},
             "zIndex": i} for i, (t, (x, y)) in enumerate(pos.items())],
        "name": "Modelo Estrella CinePlus", "zoomValue": 80, "pinKeyFieldsToTop": False,
        "showExtraHeaderInfo": False, "hideKeyFieldsWhenCollapsed": False,
        "tablesLocked": False}],
    "selectedDiagram": "Modelo Estrella CinePlus", "defaultDiagram": "Modelo Estrella CinePlus"})

print("Modelo semantico TMDL generado.")

# =====================================================================
#  2. REPORTE (PBIR)
# =====================================================================

S_VIS = f"{SCH}/item/report/definition/visualContainer/1.0.0/schema.json"
S_PAGE = f"{SCH}/item/report/definition/page/1.0.0/schema.json"
S_PAGES = f"{SCH}/item/report/definition/pagesMetadata/1.0.0/schema.json"
S_REP = f"{SCH}/item/report/definition/report/1.0.0/schema.json"
S_VER = f"{SCH}/item/report/definition/versionMetadata/1.0.0/schema.json"

# paleta
AZUL, TEAL, AMBAR = "#3D4F8C", "#009B9B", "#E8A33D"
CORAL, VERDE, MORADO = "#CF4C5E", "#5C9E6E", "#8268AE"
FONDO, PANEL, TINTA, SUAVE = "#F4F5FA", "#FFFFFF", "#1B1D2A", "#6B7085"

M = "_Medidas"


def lit(v):
    if isinstance(v, bool):
        return {"expr": {"Literal": {"Value": "true" if v else "false"}}}
    if isinstance(v, str):
        return {"expr": {"Literal": {"Value": "'" + v + "'"}}}
    if isinstance(v, int):
        return {"expr": {"Literal": {"Value": f"{v}D"}}}
    return {"expr": {"Literal": {"Value": f"{v}D"}}}


def color(hexv):
    return {"solid": {"color": lit(hexv)}}


def col(entity, prop):
    return {"Column": {"Expression": {"SourceRef": {"Entity": entity}}, "Property": prop}}


def mea(prop):
    return {"Measure": {"Expression": {"SourceRef": {"Entity": M}}, "Property": prop}}


def hier(entity, hname, level):
    return {"HierarchyLevel": {"Expression": {"Hierarchy": {
        "Expression": {"SourceRef": {"Entity": entity}}, "Hierarchy": hname}},
        "Level": level}}


def pc(entity, prop):
    """proyeccion de columna"""
    return {"field": col(entity, prop), "queryRef": f"{entity}.{prop}",
            "nativeQueryRef": prop}


def pm(prop):
    """proyeccion de medida"""
    return {"field": mea(prop), "queryRef": f"{M}.{prop}", "nativeQueryRef": prop}


def titulo_vc(texto, size=13, cfondo=PANEL):
    return {
        "title": [{"properties": {
            "text": lit(texto), "fontSize": lit(size), "bold": lit(True),
            "fontColor": color(TINTA), "alignment": lit("left"),
            "titleWrap": lit(True)}}],
        "background": [{"properties": {"show": lit(True), "color": color(cfondo),
                                       "transparency": lit(0)}}],
        "border": [{"properties": {"show": lit(True), "color": color("#E3E5EE"),
                                   "radius": lit(6)}}],
        "dropShadow": [{"properties": {"show": lit(True), "preset": lit("Soft")}}],
        "padding": [{"properties": {"left": lit(8), "right": lit(8),
                                    "top": lit(6), "bottom": lit(6)}}],
    }


VISUALES = []


def vis(page, name, x, y, wd, h, vtype, qs=None, objects=None, vco=None,
        sort=None, z=None):
    v = {"$schema": S_VIS, "name": gid(f"v:{page}:{name}"),
         "position": {"x": x, "y": y, "width": wd, "height": h,
                      "z": z if z is not None else len(VISUALES),
                      "tabOrder": len(VISUALES) * 1000}}
    conf = {"visualType": vtype}
    if qs is not None:
        q = {"queryState": qs}
        if sort:
            q["sortDefinition"] = sort
        conf["query"] = q
    if objects:
        conf["objects"] = objects
    if vco:
        conf["visualContainerObjects"] = vco
    v["visual"] = conf
    VISUALES.append((page, name, v))
    return v


def sort_desc(field):
    return {"sort": [{"field": field, "direction": "Descending"}],
            "isDefaultSort": True}


def sort_asc(field):
    return {"sort": [{"field": field, "direction": "Ascending"}],
            "isDefaultSort": True}


# ---------------------------------------------------- componentes comunes
def encabezado(page, texto, subtitulo):
    vis(page, "hdr_bg", 0, 0, 1280, 62, "shape", None,
        objects={"shape": [{"properties": {"tileShape": lit("rectangle")}}],
                 "fill": [{"properties": {"show": lit(True),
                                          "fillColor": color(AZUL)}}],
                 "outline": [{"properties": {"show": lit(False)}}]},
        z=0)
    vis(page, "hdr_txt", 20, 8, 820, 46, "textbox", None,
        objects={"general": [{"properties": {"paragraphs": [
            {"textRuns": [{"value": texto,
                           "textStyle": {"fontSize": "19pt", "fontWeight": "bold",
                                         "color": "#FFFFFF",
                                         "fontFamily": "Segoe UI"}}]},
            {"textRuns": [{"value": subtitulo,
                           "textStyle": {"fontSize": "10pt", "color": "#C9D2F0",
                                         "fontFamily": "Segoe UI"}}]}]}}]},
        vco={"background": [{"properties": {"show": lit(False)}}],
             "padding": [{"properties": {"left": lit(2), "top": lit(0)}}]},
        z=1)
    vis(page, "hdr_marca", 1010, 14, 250, 36, "textbox", None,
        objects={"general": [{"properties": {"paragraphs": [
            {"horizontalTextAlignment": "right",
             "textRuns": [{"value": "CinePlus  |  Andy Chafla",
                           "textStyle": {"fontSize": "10pt", "color": "#C9D2F0",
                                         "fontFamily": "Segoe UI"}}]}]}}]},
        vco={"background": [{"properties": {"show": lit(False)}}]},
        z=2)


def tarjeta(page, name, x, y, wd, h, medida, etiqueta, acento):
    vis(page, name, x, y, wd, h, "card",
        {"Values": {"projections": [pm(medida)]}},
        objects={
            "labels": [{"properties": {"color": color(acento), "fontSize": lit(22),
                                       "bold": lit(True),
                                       "labelDisplayUnits": lit(0)}}],
            "categoryLabels": [{"properties": {"show": lit(False)}}],
        },
        vco={"title": [{"properties": {"show": lit(True), "text": lit(etiqueta),
                                       "fontSize": lit(10), "bold": lit(True),
                                       "fontColor": color(SUAVE),
                                       "alignment": lit("left")}}],
             "background": [{"properties": {"show": lit(True), "color": color(PANEL),
                                            "transparency": lit(0)}}],
             "border": [{"properties": {"show": lit(True), "color": color("#E3E5EE"),
                                        "radius": lit(6)}}],
             "dropShadow": [{"properties": {"show": lit(True), "preset": lit("Soft")}}],
             "padding": [{"properties": {"left": lit(10), "right": lit(10),
                                         "top": lit(6), "bottom": lit(6)}}]})


def tarjeta_texto(page, name, x, y, wd, h, medida, etiqueta, acento):
    vis(page, name, x, y, wd, h, "card",
        {"Values": {"projections": [pm(medida)]}},
        objects={"labels": [{"properties": {"color": color(acento),
                                            "fontSize": lit(14), "bold": lit(True)}}],
                 "categoryLabels": [{"properties": {"show": lit(False)}}]},
        vco={"title": [{"properties": {"show": lit(True), "text": lit(etiqueta),
                                       "fontSize": lit(10), "bold": lit(True),
                                       "fontColor": color(SUAVE),
                                       "alignment": lit("left")}}],
             "background": [{"properties": {"show": lit(True), "color": color(PANEL)}}],
             "border": [{"properties": {"show": lit(True), "color": color("#E3E5EE"),
                                        "radius": lit(6)}}],
             "dropShadow": [{"properties": {"show": lit(True), "preset": lit("Soft")}}],
             "padding": [{"properties": {"left": lit(10), "right": lit(10),
                                         "top": lit(6), "bottom": lit(6)}}]})


def segmentador(page, name, x, y, wd, h, entity, prop, etiqueta, modo="Dropdown"):
    vis(page, name, x, y, wd, h, "slicer",
        {"Values": {"projections": [pc(entity, prop)]}},
        objects={"data": [{"properties": {"mode": lit(modo)}}],
                 "header": [{"properties": {"show": lit(False)}}],
                 "items": [{"properties": {"fontColor": color(TINTA),
                                           "fontSize": lit(10)}}]},
        vco={"title": [{"properties": {"show": lit(True), "text": lit(etiqueta),
                                       "fontSize": lit(10), "bold": lit(True),
                                       "fontColor": color(SUAVE)}}],
             "background": [{"properties": {"show": lit(True), "color": color(PANEL)}}],
             "border": [{"properties": {"show": lit(True), "color": color("#E3E5EE"),
                                        "radius": lit(6)}}],
             "padding": [{"properties": {"left": lit(8), "right": lit(8),
                                         "top": lit(4), "bottom": lit(4)}}]})


def ejes(cat_size=10, val_size=10):
    return {
        "categoryAxis": [{"properties": {"show": lit(True), "fontSize": lit(cat_size),
                                         "labelColor": color(SUAVE),
                                         "showAxisTitle": lit(False)}}],
        "valueAxis": [{"properties": {"show": lit(True), "fontSize": lit(val_size),
                                      "labelColor": color(SUAVE),
                                      "showAxisTitle": lit(False),
                                      "gridlineColor": color("#EDEFF5")}}],
    }


def etiquetas(size=9, unidades=0):
    return {"labels": [{"properties": {"show": lit(True), "fontSize": lit(size),
                                       "color": color(TINTA),
                                       "labelDisplayUnits": lit(unidades)}}]}


def leyenda(pos="Right"):
    return {"legend": [{"properties": {"show": lit(True), "position": lit(pos),
                                       "fontSize": lit(9),
                                       "labelColor": color(SUAVE),
                                       "showTitle": lit(False)}}]}


def sin_leyenda():
    return {"legend": [{"properties": {"show": lit(False)}}]}


def color_serie(hexv):
    return {"dataPoint": [{"properties": {"fill": color(hexv)}}]}


def fusion(*ds):
    out = {}
    for d in ds:
        for k, v in d.items():
            out.setdefault(k, []).extend(v) if k in out else out.update({k: v})
    return out


# =============================================== PAGINA 1 - PAIS Y GENERO
P1 = "ReportePaisGenero"
encabezado(P1, "Reporte 1 — Visualizaciones por Pais y Genero",
           "Sesion 2 · Distribucion geografica y preferencias de contenido · CinePlus_Cubo")

for i, (med, etq, ac) in enumerate([
        ("Total Visualizaciones", "TOTAL VISUALIZACIONES", AZUL),
        ("Usuarios Unicos", "USUARIOS UNICOS", TEAL),
        ("Horas Vistas", "HORAS VISTAS", AMBAR),
        ("% Completitud", "% COMPLETITUD", VERDE)]):
    tarjeta(P1, f"kpi{i}", 20 + i * 196, 74, 180, 76, med, etq, ac)

segmentador(P1, "slc_anio", 812, 74, 148, 76, "DimTiempo", "Mes", "MES")
segmentador(P1, "slc_plan", 968, 74, 148, 76, "DimUsuario", "TipoPlan", "PLAN")
segmentador(P1, "slc_tipo", 1124, 74, 136, 76, "DimContenido", "TipoContenido", "TIPO")

vis(P1, "bar_pais", 20, 162, 400, 268, "barChart",
    {"Category": {"projections": [pc("DimPais", "Pais")]},
     "Y": {"projections": [pm("Total Visualizaciones")]}},
    objects=fusion(ejes(), etiquetas(), sin_leyenda(), color_serie(AZUL)),
    vco=titulo_vc("Visualizaciones por pais"),
    sort=sort_desc(mea("Total Visualizaciones")))

vis(P1, "col_genero", 428, 162, 400, 268, "columnChart",
    {"Category": {"projections": [pc("DimGenero", "Genero")]},
     "Y": {"projections": [pm("Total Visualizaciones")]}},
    objects=fusion(ejes(), etiquetas(), sin_leyenda(), color_serie(TEAL)),
    vco=titulo_vc("Visualizaciones por genero"),
    sort=sort_desc(mea("Total Visualizaciones")))

vis(P1, "don_region", 836, 162, 424, 268, "donutChart",
    {"Category": {"projections": [pc("DimPais", "Region")]},
     "Y": {"projections": [pm("Horas Vistas")]}},
    objects=fusion(leyenda("Right"),
                   {"labels": [{"properties": {"show": lit(True), "fontSize": lit(9),
                                               "labelStyle": lit("Category, percent of total")}}]},
                   {"slices": [{"properties": {"innerRadiusRatio": lit(60)}}]}),
    vco=titulo_vc("Horas vistas por region"))

vis(P1, "matriz", 20, 438, 1240, 258, "pivotTable",
    {"Rows": {"projections": [pc("DimPais", "Pais")]},
     "Columns": {"projections": [pc("DimGenero", "Genero")]},
     "Values": {"projections": [pm("Total Visualizaciones")]}},
    objects={
        "grid": [{"properties": {"gridVertical": lit(True),
                                 "gridVerticalColor": color("#EDEFF5"),
                                 "gridHorizontalColor": color("#EDEFF5"),
                                 "rowPadding": lit(2)}}],
        "columnHeaders": [{"properties": {"fontColor": color(PANEL),
                                          "backColor": color(AZUL),
                                          "bold": lit(True), "fontSize": lit(9)}}],
        "rowHeaders": [{"properties": {"fontSize": lit(9), "fontColor": color(TINTA)}}],
        "values": [{"properties": {"fontSize": lit(9), "fontColor": color(TINTA),
                                   "backColorPrimary": color(PANEL),
                                   "backColorSecondary": color("#FAFBFF")}}],
        "subTotals": [{"properties": {"rowSubtotals": lit(True),
                                      "columnSubtotals": lit(True)}}],
    },
    vco=titulo_vc("Matriz pais x genero — total de visualizaciones"))

# ================================================ PAGINA 2 - TOP 10
P2 = "ReporteTop10"
encabezado(P2, "Reporte 2 — Top 10 de contenidos mas vistos",
           "Sesion 2 · Ranking del catalogo por reproducciones · CinePlus_Cubo")

tarjeta_texto(P2, "kpi_top1", 20, 74, 330, 76, "Contenido Mas Visto",
              "CONTENIDO N.º 1", AZUL)
tarjeta(P2, "kpi_cont", 358, 74, 180, 76, "Contenidos Unicos",
        "TITULOS REPRODUCIDOS", TEAL)
tarjeta(P2, "kpi_val", 546, 74, 180, 76, "Valoracion Promedio",
        "VALORACION MEDIA", AMBAR)
tarjeta(P2, "kpi_prom", 734, 74, 180, 76, "Promedio Minutos por Visualizacion",
        "MIN. POR SESION", MORADO)

segmentador(P2, "slc_gen", 922, 74, 164, 76, "DimGenero", "Genero", "GENERO")
segmentador(P2, "slc_pais", 1094, 74, 166, 76, "DimPais", "Pais", "PAIS")

vis(P2, "bar_top10", 20, 162, 620, 534, "barChart",
    {"Category": {"projections": [pc("DimContenido", "Titulo")]},
     "Y": {"projections": [pm("Top 10 Contenidos")]}},
    objects=fusion(ejes(10, 10), etiquetas(10), sin_leyenda(), color_serie(AZUL)),
    vco=titulo_vc("Top 10 por numero de visualizaciones"),
    sort=sort_desc(mea("Top 10 Contenidos")))

vis(P2, "tbl_detalle", 648, 162, 612, 348, "tableEx",
    {"Values": {"projections": [
        pc("DimContenido", "Titulo"),
        pc("DimGenero", "Genero"),
        pc("DimContenido", "TipoContenido"),
        pm("Total Visualizaciones"),
        pm("Horas Vistas"),
        pm("% Completitud"),
        pm("Ranking Contenido")]}},
    objects={
        "grid": [{"properties": {"gridVertical": lit(True),
                                 "gridVerticalColor": color("#EDEFF5"),
                                 "gridHorizontalColor": color("#EDEFF5"),
                                 "rowPadding": lit(2)}}],
        "columnHeaders": [{"properties": {"fontColor": color(PANEL),
                                          "backColor": color(AZUL),
                                          "bold": lit(True), "fontSize": lit(9),
                                          "wordWrap": lit(True)}}],
        "values": [{"properties": {"fontSize": lit(9), "fontColor": color(TINTA),
                                   "backColorPrimary": color(PANEL),
                                   "backColorSecondary": color("#FAFBFF")}}],
        "total": [{"properties": {"fontColor": color(TINTA), "backColor": color("#EEF0F8"),
                                  "bold": lit(True), "fontSize": lit(9)}}],
    },
    vco=titulo_vc("Detalle del catalogo"),
    sort=sort_asc(mea("Ranking Contenido")))

vis(P2, "col_tipo", 648, 518, 300, 178, "columnChart",
    {"Category": {"projections": [pc("DimContenido", "TipoContenido")]},
     "Y": {"projections": [pm("Total Visualizaciones")]}},
    objects=fusion(ejes(9, 9), etiquetas(9), sin_leyenda(), color_serie(TEAL)),
    vco=titulo_vc("Pelicula vs serie"))

vis(P2, "col_origen", 960, 518, 300, 178, "columnChart",
    {"Category": {"projections": [pc("DimContenido", "OrigenContenido")]},
     "Y": {"projections": [pm("Total Visualizaciones")]}},
    objects=fusion(ejes(9, 9), etiquetas(9), sin_leyenda(), color_serie(AMBAR)),
    vco=titulo_vc("Original vs licenciado"))

# ============================================ PAGINA 3 - PRIME TIME
P3 = "ReportePrimeTime"
encabezado(P3, "Reporte 3 — Dispositivos mas usados en horario prime",
           "Sesion 2 · Franja estelar 19:00 a 22:59 · CinePlus_Cubo")

tarjeta(P3, "kpi_prime", 20, 74, 190, 76, "Visualizaciones Prime Time",
        "VISUALIZACIONES PRIME", AZUL)
tarjeta(P3, "kpi_pct", 218, 74, 180, 76, "% Prime Time", "% DEL CONSUMO TOTAL", CORAL)
tarjeta(P3, "kpi_horas", 406, 74, 180, 76, "Horas Prime Time", "HORAS EN PRIME", AMBAR)
tarjeta_texto(P3, "kpi_lider", 594, 74, 300, 76, "Dispositivo Lider Prime",
              "DISPOSITIVO LIDER EN PRIME", TEAL)

segmentador(P3, "slc_pais3", 902, 74, 174, 76, "DimPais", "Pais", "PAIS")
segmentador(P3, "slc_franja", 1084, 74, 176, 76, "DimHora", "FranjaHoraria", "FRANJA")

vis(P3, "don_disp", 20, 162, 420, 290, "donutChart",
    {"Category": {"projections": [pc("DimDispositivo", "Dispositivo")]},
     "Y": {"projections": [pm("Visualizaciones Prime Time")]}},
    objects=fusion(leyenda("Right"),
                   {"labels": [{"properties": {"show": lit(True), "fontSize": lit(9),
                                               "labelStyle": lit("Percent of total")}}]},
                   {"slices": [{"properties": {"innerRadiusRatio": lit(58)}}]}),
    vco=titulo_vc("Reparto de dispositivos en prime time"))

vis(P3, "col_hora", 448, 162, 812, 290, "columnChart",
    {"Category": {"projections": [pc("DimHora", "Hora")]},
     "Y": {"projections": [pm("Total Visualizaciones")]},
     "Series": {"projections": [pc("DimHora", "PrimeTimeDesc")]}},
    objects=fusion(ejes(9, 9), leyenda("Top"),
                   {"labels": [{"properties": {"show": lit(False)}}]}),
    vco=titulo_vc("Curva de consumo por hora del dia (prime destacado)"),
    sort=sort_asc(col("DimHora", "Hora")))

vis(P3, "bar_disp_franja", 20, 460, 620, 236, "clusteredBarChart",
    {"Category": {"projections": [pc("DimDispositivo", "Dispositivo")]},
     "Y": {"projections": [pm("Visualizaciones Prime Time"),
                           pm("Visualizaciones Fuera de Prime")]}},
    objects=fusion(ejes(9, 9), leyenda("Top"),
                   {"labels": [{"properties": {"show": lit(False)}}]}),
    vco=titulo_vc("Dispositivo: prime time vs resto del dia"),
    sort=sort_desc(mea("Visualizaciones Prime Time")))

vis(P3, "tbl_disp", 648, 460, 612, 236, "tableEx",
    {"Values": {"projections": [
        pc("DimDispositivo", "Dispositivo"),
        pc("DimDispositivo", "TipoDispositivo"),
        pm("Visualizaciones Prime Time"),
        pm("% Prime Time"),
        pm("Promedio Minutos por Visualizacion"),
        pm("% Completitud")]}},
    objects={
        "grid": [{"properties": {"gridVertical": lit(True),
                                 "gridVerticalColor": color("#EDEFF5"),
                                 "gridHorizontalColor": color("#EDEFF5"),
                                 "rowPadding": lit(2)}}],
        "columnHeaders": [{"properties": {"fontColor": color(PANEL),
                                          "backColor": color(AZUL), "bold": lit(True),
                                          "fontSize": lit(9), "wordWrap": lit(True)}}],
        "values": [{"properties": {"fontSize": lit(9), "fontColor": color(TINTA),
                                   "backColorPrimary": color(PANEL),
                                   "backColorSecondary": color("#FAFBFF")}}],
    },
    vco=titulo_vc("Rendimiento por dispositivo"),
    sort=sort_desc(mea("Visualizaciones Prime Time")))

# ============================================ PAGINA 4 - DASHBOARD
P4 = "DashboardEjecutivo"
encabezado(P4, "Dashboard Ejecutivo CinePlus",
           "Sesion 3 · Panel interactivo consolidado · Ejercicio 2025")

for i, (med, etq, ac) in enumerate([
        ("Total Visualizaciones", "VISUALIZACIONES", AZUL),
        ("Usuarios Unicos", "USUARIOS ACTIVOS", TEAL),
        ("Horas Vistas", "HORAS VISTAS", AMBAR),
        ("% Prime Time", "% PRIME TIME", CORAL),
        ("% Completitud", "% COMPLETITUD", VERDE)]):
    tarjeta(P4, f"k{i}", 20 + i * 196, 74, 180, 76, med, etq, ac)

segmentador(P4, "d_slc_mes", 1004, 74, 124, 76, "DimTiempo", "Mes", "MES")
segmentador(P4, "d_slc_pais", 1136, 74, 124, 76, "DimPais", "Pais", "PAIS")

vis(P4, "lin_tendencia", 20, 162, 820, 250, "lineChart",
    {"Category": {"projections": [pc("DimTiempo", "Mes")]},
     "Y": {"projections": [pm("Total Visualizaciones")]}},
    objects=fusion(ejes(9, 9), sin_leyenda(), color_serie(AZUL),
                   {"labels": [{"properties": {"show": lit(False)}}]},
                   {"lineStyles": [{"properties": {"strokeWidth": lit(3),
                                                   "showMarker": lit(True),
                                                   "lineStyle": lit("solid")}}]}),
    vco=titulo_vc("Tendencia mensual de visualizaciones"),
    sort=sort_asc(col("DimTiempo", "NumeroMes")))

vis(P4, "don_disp4", 848, 162, 412, 250, "donutChart",
    {"Category": {"projections": [pc("DimDispositivo", "Dispositivo")]},
     "Y": {"projections": [pm("Total Visualizaciones")]}},
    objects=fusion(leyenda("Right"),
                   {"labels": [{"properties": {"show": lit(True), "fontSize": lit(9),
                                               "labelStyle": lit("Percent of total")}}]},
                   {"slices": [{"properties": {"innerRadiusRatio": lit(60)}}]}),
    vco=titulo_vc("Mix de dispositivos"))

vis(P4, "bar_pais4", 20, 420, 406, 276, "barChart",
    {"Category": {"projections": [pc("DimPais", "Pais")]},
     "Y": {"projections": [pm("Horas Vistas")]}},
    objects=fusion(ejes(9, 9), etiquetas(9), sin_leyenda(), color_serie(TEAL)),
    vco=titulo_vc("Horas vistas por pais"),
    sort=sort_desc(mea("Horas Vistas")))

vis(P4, "col_gen4", 434, 420, 406, 276, "columnChart",
    {"Category": {"projections": [pc("DimGenero", "Genero")]},
     "Y": {"projections": [pm("Total Visualizaciones")]}},
    objects=fusion(ejes(9, 9), etiquetas(9), sin_leyenda(), color_serie(AMBAR)),
    vco=titulo_vc("Visualizaciones por genero"),
    sort=sort_desc(mea("Total Visualizaciones")))

vis(P4, "bar_top4", 848, 420, 412, 276, "barChart",
    {"Category": {"projections": [pc("DimContenido", "Titulo")]},
     "Y": {"projections": [pm("Top 10 Contenidos")]}},
    objects=fusion(ejes(9, 9), etiquetas(9), sin_leyenda(), color_serie(MORADO)),
    vco=titulo_vc("Top 10 contenidos"),
    sort=sort_desc(mea("Top 10 Contenidos")))

# ------------------------------------------------------ escritura paginas
PAGINAS = [
    (P1, "1 · Pais y Genero"),
    (P2, "2 · Top 10 Contenidos"),
    (P3, "3 · Prime Time"),
    (P4, "4 · Dashboard Ejecutivo"),
]

for pname, display in PAGINAS:
    pdir = os.path.join(RP, "definition", "pages", pname)
    wj(os.path.join(pdir, "page.json"), {
        "$schema": S_PAGE,
        "name": pname,
        "displayName": display,
        "displayOption": "FitToPage",
        "height": 720,
        "width": 1280,
        "objects": {
            "background": [{"properties": {"color": color(FONDO),
                                           "transparency": lit(0)}}],
            "outspace": [{"properties": {"color": color("#E9EBF3"),
                                         "transparency": lit(0)}}],
            "displayArea": [{"properties": {"verticalAlignment": lit("Top")}}],
        },
    })
    for p, vname, vobj in VISUALES:
        if p != pname:
            continue
        wj(os.path.join(pdir, "visuals", vobj["name"], "visual.json"), vobj)

wj(os.path.join(RP, "definition", "pages", "pages.json"), {
    "$schema": S_PAGES,
    "pageOrder": [p for p, _ in PAGINAS],
    "activePageName": P4,
})

wj(os.path.join(RP, "definition", "version.json"),
   {"$schema": S_VER, "version": "2.0.0"})

wj(os.path.join(RP, "definition", "report.json"), {
    "$schema": S_REP,
    "layoutOptimization": "None",
    "themeCollection": {
        "customTheme": {"name": "CinePlus", "reportVersionAtImport": "5.61",
                        "type": "RegisteredResources"}},
    "resourcePackages": [{
        "name": "RegisteredResources",
        "type": "RegisteredResources",
        "items": [{"name": "CinePlus.json", "path": "CinePlus.json",
                   "type": "CustomTheme"}]}],
    "settings": {
        "useStylableVisualContainerHeader": True,
        "defaultDrillFilterOtherVisuals": True,
        "allowChangeFilterTypes": True,
    },
})

# tema
wj(os.path.join(RP, "StaticResources", "RegisteredResources", "CinePlus.json"), {
    "name": "CinePlus",
    "dataColors": [AZUL, TEAL, AMBAR, CORAL, VERDE, MORADO,
                   "#E07A5F", "#2F6690", "#B08968", "#4C956C"],
    "background": PANEL,
    "foreground": TINTA,
    "tableAccent": AZUL,
    "good": VERDE, "neutral": AMBAR, "bad": CORAL,
    "textClasses": {
        "title":    {"fontFace": "Segoe UI Semibold", "fontSize": 13, "color": TINTA},
        "label":    {"fontFace": "Segoe UI", "fontSize": 10, "color": SUAVE},
        "callout":  {"fontFace": "Segoe UI Semibold", "fontSize": 24, "color": AZUL},
        "header":   {"fontFace": "Segoe UI Semibold", "fontSize": 12, "color": TINTA},
    },
})

wj(os.path.join(RP, "definition.pbir"),
   {"$schema": f"{SCH}/item/report/definitionProperties/2.0.0/schema.json",
    "version": "4.0",
    "datasetReference": {"byPath": {"path": "../CinePlus.SemanticModel"}}})

wj(os.path.join(RP, ".platform"),
   {"$schema": f"{SCH}/gitIntegration/platformProperties/2.0.0/schema.json",
    "metadata": {"type": "Report", "displayName": "CinePlus"},
    "config": {"version": "2.0", "logicalId": gid("logical:rp")}})

wj(os.path.join(PBIP, "CinePlus.pbip"),
   {"version": "1.0",
    "artifacts": [{"report": {"path": "CinePlus.Report"}}],
    "settings": {"enableAutoRecovery": True}})

print(f"Reporte PBIR generado: {len(PAGINAS)} paginas, {len(VISUALES)} visuales.")
print(f"Proyecto en: {PBIP}")
