# -*- coding: utf-8 -*-
"""
Validador del proyecto PBIP contra los esquemas oficiales de Microsoft.

Descarga (y cachea) los esquemas publicados en developer.microsoft.com
y valida cada archivo JSON del reporte. Tambien revisa coherencia interna:
que cada medida/columna referenciada en los visuales exista en el modelo TMDL.

Uso:  python scripts/validar_pbip.py
"""

import json
import os
import re
import sys
import urllib.request
from urllib.parse import urljoin

from jsonschema import Draft7Validator
from referencing import Registry, Resource
from referencing.jsonschema import DRAFT7

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PBIP = os.path.join(BASE, "pbip")
CACHE = os.path.join(BASE, "scripts", ".cache_esquemas")
os.makedirs(CACHE, exist_ok=True)

_mem = {}


def traer(url):
    if url in _mem:
        return _mem[url]
    nombre = re.sub(r"[^A-Za-z0-9]+", "_", url)[-120:] + ".json"
    ruta = os.path.join(CACHE, nombre)
    if os.path.exists(ruta):
        with open(ruta, encoding="utf-8") as f:
            doc = json.load(f)
    else:
        req = urllib.request.Request(url, headers={"User-Agent": "schema-validator"})
        with urllib.request.urlopen(req, timeout=40) as r:
            doc = json.loads(r.read().decode("utf-8"))
        with open(ruta, "w", encoding="utf-8") as f:
            json.dump(doc, f)
    _mem[url] = doc
    return doc


def recuperar(uri):
    return Resource.from_contents(traer(uri), default_specification=DRAFT7)


registro = Registry(retrieve=recuperar)


def validar(ruta):
    with open(ruta, encoding="utf-8") as f:
        doc = json.load(f)
    url = doc.get("$schema")
    if not url:
        return []
    esquema = traer(url)
    v = Draft7Validator(esquema, registry=registro.with_resource(url, Resource.from_contents(esquema, default_specification=DRAFT7)))
    fallos = []
    for e in sorted(v.iter_errors(doc), key=lambda x: list(x.path)):
        camino = "/".join(str(p) for p in e.path) or "(raiz)"
        fallos.append(f"{camino}: {e.message[:200]}")
    return fallos


# ------------------------------------------------- 1. validacion de esquema
print("== Validacion contra esquemas oficiales de Microsoft ==")
archivos = []
for raiz, _, files in os.walk(PBIP):
    for f in files:
        if f.endswith((".json", ".pbir", ".pbism", ".pbip")):
            archivos.append(os.path.join(raiz, f))

total_err = 0
validados = 0
for a in sorted(archivos):
    rel = os.path.relpath(a, BASE)
    try:
        errs = validar(a)
    except Exception as ex:
        print(f"  [ERROR] {rel}: {type(ex).__name__}: {ex}")
        total_err += 1
        continue
    with open(a, encoding="utf-8") as fh:
        tiene = "$schema" in json.load(fh)
    if not tiene:
        continue
    validados += 1
    if errs:
        total_err += len(errs)
        print(f"  [FALLA] {rel}")
        for e in errs[:6]:
            print(f"          {e}")

print(f"  Archivos con $schema validados: {validados}")
print(f"  Errores de esquema: {total_err}")

# ------------------------------------- 2. coherencia reporte <-> modelo TMDL
print("\n== Coherencia entre el reporte y el modelo semantico ==")
tdir = os.path.join(PBIP, "CinePlus.SemanticModel", "definition", "tables")
columnas, medidas, jerarquias = set(), set(), set()
for f in os.listdir(tdir):
    tabla = f[:-5]
    with open(os.path.join(tdir, f), encoding="utf-8") as fh:
        for ln in fh:
            m = re.match(r"\tcolumn '?([^'\n]+?)'?$", ln.rstrip("\n"))
            if m:
                columnas.add((tabla, m.group(1)))
            m = re.match(r"\tmeasure '?([^'=]+?)'? =", ln.rstrip("\n"))
            if m:
                medidas.add(m.group(1).strip())
            m = re.match(r"\thierarchy '?([^'\n]+?)'?$", ln.rstrip("\n"))
            if m:
                jerarquias.add((tabla, m.group(1)))

faltantes = []
usadas_med, usadas_col = set(), set()
for raiz, _, files in os.walk(os.path.join(PBIP, "CinePlus.Report")):
    for f in files:
        if f != "visual.json":
            continue
        ruta = os.path.join(raiz, f)
        doc = json.load(open(ruta, encoding="utf-8"))
        def recorrer(o):
            if isinstance(o, dict):
                if "Column" in o and isinstance(o["Column"], dict):
                    c = o["Column"]
                    ent = c.get("Expression", {}).get("SourceRef", {}).get("Entity")
                    pr = c.get("Property")
                    if ent and pr:
                        usadas_col.add((ent, pr))
                        if (ent, pr) not in columnas:
                            faltantes.append(f"columna {ent}[{pr}]")
                if "Measure" in o and isinstance(o["Measure"], dict):
                    c = o["Measure"]
                    pr = c.get("Property")
                    if pr:
                        usadas_med.add(pr)
                        if pr not in medidas:
                            faltantes.append(f"medida [{pr}]")
                for v in o.values():
                    recorrer(v)
            elif isinstance(o, list):
                for v in o:
                    recorrer(v)

        recorrer(doc)

print(f"  Columnas en el modelo: {len(columnas)} | medidas: {len(medidas)} | jerarquias: {len(jerarquias)}")
print(f"  Columnas usadas en visuales: {len(usadas_col)} | medidas usadas: {len(usadas_med)}")
if faltantes:
    print("  [FALLA] Referencias rotas:")
    for x in sorted(set(faltantes)):
        print("         ", x)
else:
    print("  OK: todas las referencias de los visuales existen en el modelo.")

sin_usar = sorted(medidas - usadas_med)
if sin_usar:
    print(f"  Aviso: medidas definidas pero no usadas en visuales ({len(sin_usar)}): {', '.join(sin_usar)}")

# ------------------------------------------- 3. CSV referenciados por el modelo
print("\n== Origen de datos ==")
exp = open(os.path.join(PBIP, "CinePlus.SemanticModel", "definition", "expressions.tmdl"),
           encoding="utf-8").read()
ruta_datos = re.search(r'expression RutaDatos = "([^"]+)"', exp).group(1)
print(f"  Parametro RutaDatos = {ruta_datos}")
falta_csv = []
for f in sorted(os.listdir(tdir)):
    t = f[:-5]
    if t == "_Medidas":
        continue
    if not os.path.exists(os.path.join(ruta_datos, t + ".csv")):
        falta_csv.append(t + ".csv")
if falta_csv:
    print("  [FALLA] CSV no encontrados:", ", ".join(falta_csv))
else:
    print("  OK: los 8 CSV del Data Warehouse existen en la ruta configurada.")

print("\n== Resultado ==")
if total_err == 0 and not faltantes and not falta_csv:
    print("  PROYECTO VALIDO")
    sys.exit(0)
print("  SE ENCONTRARON PROBLEMAS")
sys.exit(1)
