# -*- coding: utf-8 -*-
"""
Genera capturas (anexos) de las 4 páginas del reporte CinePlus
con los mismos KPIs y cifras que docs/hallazgos.md.
"""

from __future__ import annotations

import os
from pathlib import Path

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import pandas as pd
from matplotlib.gridspec import GridSpec
from PIL import Image, ImageDraw, ImageFont

BASE = Path(__file__).resolve().parents[1]
DATOS = BASE / "datos"
OUT = BASE / "anexos" / "capturas"
OUT.mkdir(parents=True, exist_ok=True)

# Paleta estilo Power BI (cabecera azul de la práctica)
BLUE = "#1F4E79"
BLUE2 = "#2E75B6"
ACCENT = "#5B9BD5"
ORANGE = "#ED7D31"
GREEN = "#70AD47"
GRAY = "#595959"
BG = "#F3F3F3"
CARD = "#FFFFFF"
PRIME = "#C00000"
NO_PRIME = "#9DC3E6"


def read_csv(name: str) -> pd.DataFrame:
    return pd.read_csv(DATOS / name, sep=";", encoding="utf-8-sig")


def load():
    fact = read_csv("FactVisualizaciones.csv")
    pais = read_csv("DimPais.csv")
    genero = read_csv("DimGenero.csv")
    contenido = read_csv("DimContenido.csv").rename(columns={"GeneroID": "GeneroID_contenido"})
    dispositivo = read_csv("DimDispositivo.csv")
    hora = read_csv("DimHora.csv").drop(columns=["EsPrimeTime"], errors="ignore")
    tiempo = read_csv("DimTiempo.csv")
    usuario = read_csv("DimUsuario.csv").drop(columns=["PaisID", "Genero"], errors="ignore")

    f = fact.merge(pais, on="PaisID", how="left")
    f = f.merge(contenido, on="ContenidoID", how="left")
    f = f.merge(genero, left_on="GeneroID_contenido", right_on="GeneroID",
                how="left", suffixes=("", "_g"))
    f = f.merge(dispositivo, on="DispositivoID", how="left")
    f = f.merge(hora, on="HoraKey", how="left")
    f = f.merge(tiempo, on="FechaKey", how="left")
    f = f.merge(usuario, on="UsuarioID", how="left", suffixes=("", "_u"))
    return f


def fmt_int(n: float) -> str:
    return f"{int(round(n)):,}".replace(",", ".")


def fmt_pct(n: float) -> str:
    return f"{n * 100:.1f}%".replace(".", ",")


def draw_header(ax, title: str, subtitle: str = "CinePlus · Power BI"):
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    ax.add_patch(mpatches.FancyBboxPatch((0, 0), 1, 1, boxstyle="square,pad=0",
                                         facecolor=BLUE, edgecolor="none", transform=ax.transAxes))
    ax.text(0.02, 0.62, title, color="white", fontsize=16, fontweight="bold",
            va="center", transform=ax.transAxes)
    ax.text(0.02, 0.22, subtitle, color="#D6E3F0", fontsize=9, va="center",
            transform=ax.transAxes)
    ax.text(0.98, 0.5, "Andy Chafla", color="white", fontsize=10, ha="right",
            va="center", transform=ax.transAxes)


def kpi_card(ax, label: str, value: str, accent=BLUE2):
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    ax.add_patch(mpatches.FancyBboxPatch((0.02, 0.08), 0.96, 0.84,
                                         boxstyle="round,pad=0.02,rounding_size=0.05",
                                         facecolor=CARD, edgecolor="#D0D0D0",
                                         linewidth=0.8, transform=ax.transAxes))
    ax.add_patch(mpatches.Rectangle((0.02, 0.08), 0.015, 0.84, facecolor=accent,
                                    edgecolor="none", transform=ax.transAxes))
    ax.text(0.12, 0.68, label, fontsize=8, color=GRAY, va="center", transform=ax.transAxes)
    ax.text(0.12, 0.32, value, fontsize=15, fontweight="bold", color=BLUE,
            va="center", transform=ax.transAxes)


def style_ax(ax, title: str):
    ax.set_facecolor(CARD)
    ax.set_title(title, fontsize=10, fontweight="bold", color=BLUE, loc="left", pad=8)
    ax.tick_params(colors=GRAY, labelsize=8)
    for spine in ax.spines.values():
        spine.set_color("#E0E0E0")
    ax.grid(axis="y", color="#EEEEEE", linewidth=0.6)
    ax.set_axisbelow(True)


def page_pais_genero(df: pd.DataFrame, path: Path):
    total = len(df)
    usuarios = df["UsuarioID"].nunique()
    horas = df["MinutosVistos"].sum() / 60
    completitud = df["Completado"].mean()

    fig = plt.figure(figsize=(12.8, 7.2), dpi=140, facecolor=BG)
    gs = GridSpec(4, 4, figure=fig, height_ratios=[0.55, 0.7, 1.6, 1.5],
                  hspace=0.45, wspace=0.35,
                  left=0.05, right=0.97, top=0.96, bottom=0.06)

    draw_header(fig.add_subplot(gs[0, :]),
                "Reporte 1: Visualizaciones por País y Género",
                "Sesión 2 · Reportes ejecutivos")

    kpis = [
        ("Total Visualizaciones", fmt_int(total), BLUE2),
        ("Usuarios Únicos", fmt_int(usuarios), GREEN),
        ("Horas Vistas", fmt_int(horas), ORANGE),
        ("% Completitud", fmt_pct(completitud), ACCENT),
    ]
    for i, (lab, val, col) in enumerate(kpis):
        kpi_card(fig.add_subplot(gs[1, i]), lab, val, col)

    # barras país
    ax1 = fig.add_subplot(gs[2, 0:2])
    pais = df.groupby("Pais").size().sort_values(ascending=True)
    ax1.barh(pais.index, pais.values, color=BLUE2)
    style_ax(ax1, "Visualizaciones por país")
    ax1.set_xlabel("")

    # columnas género
    ax2 = fig.add_subplot(gs[2, 2])
    gen = df.groupby("Genero").size().sort_values(ascending=False)
    ax2.bar(range(len(gen)), gen.values, color=ACCENT)
    ax2.set_xticks(range(len(gen)))
    ax2.set_xticklabels(gen.index, rotation=45, ha="right", fontsize=7)
    style_ax(ax2, "Visualizaciones por género")

    # anillo región
    ax3 = fig.add_subplot(gs[2, 3])
    reg = df.groupby("Region")["MinutosVistos"].sum() / 60
    colors = plt.cm.Blues(np.linspace(0.35, 0.9, len(reg)))
    wedges, _ = ax3.pie(reg.values, colors=colors, startangle=90,
                        wedgeprops=dict(width=0.45, edgecolor="white"))
    ax3.set_title("Horas por región", fontsize=10, fontweight="bold", color=BLUE, loc="left")
    ax3.legend(wedges, [f"{i}" for i in reg.index], fontsize=6, loc="center left",
               bbox_to_anchor=(0.95, 0.5), frameon=False)

    # matriz
    ax4 = fig.add_subplot(gs[3, :])
    mat = pd.crosstab(df["Pais"], df["Genero"])
    # ordenar países por total
    order = df.groupby("Pais").size().sort_values(ascending=False).index
    mat = mat.loc[order]
    im = ax4.imshow(mat.values, aspect="auto", cmap="Blues")
    ax4.set_xticks(range(len(mat.columns)))
    ax4.set_xticklabels(mat.columns, rotation=35, ha="right", fontsize=7)
    ax4.set_yticks(range(len(mat.index)))
    ax4.set_yticklabels(mat.index, fontsize=8)
    ax4.set_title("Matriz País × Género (visualizaciones)", fontsize=10,
                  fontweight="bold", color=BLUE, loc="left")
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            v = mat.values[i, j]
            ax4.text(j, i, str(v), ha="center", va="center", fontsize=6,
                     color="white" if v > mat.values.max() * 0.55 else GRAY)

    fig.savefig(path, dpi=140, facecolor=fig.get_facecolor())
    plt.close(fig)


def page_top10(df: pd.DataFrame, path: Path):
    ranking = (
        df.groupby(["Titulo", "Genero", "TipoContenido", "OrigenContenido"], as_index=False)
        .agg(
            vis=("VisualizacionID", "count"),
            horas=("MinutosVistos", "sum"),
            complet=("Completado", "mean"),
            valor=("Valoracion", "mean"),
        )
    )
    ranking["horas"] = ranking["horas"] / 60
    ranking = ranking.sort_values("vis", ascending=False).reset_index(drop=True)
    ranking["rank"] = ranking.index + 1
    top = ranking.head(10).iloc[::-1]

    contenido_mas = ranking.iloc[0]["Titulo"]
    contenidos = df["ContenidoID"].nunique()
    valoracion = df.loc[df["Valoracion"].notna(), "Valoracion"].mean()
    prom_min = df["MinutosVistos"].mean()

    fig = plt.figure(figsize=(12.8, 7.2), dpi=140, facecolor=BG)
    gs = GridSpec(4, 4, figure=fig, height_ratios=[0.55, 0.7, 1.8, 1.4],
                  hspace=0.45, wspace=0.35,
                  left=0.06, right=0.97, top=0.96, bottom=0.07)

    draw_header(fig.add_subplot(gs[0, :]),
                "Reporte 2: Top 10 de contenidos más vistos",
                "Sesión 2 · Ranking dinámico con RANKX")

    kpis = [
        ("Contenido Más Visto", str(contenido_mas)[:22], ORANGE),
        ("Contenidos Únicos", fmt_int(contenidos), BLUE2),
        ("Valoración Promedio", f"{valoracion:.2f}".replace(".", ","), GREEN),
        ("Prom. Min / Vis.", f"{prom_min:.1f}".replace(".", ","), ACCENT),
    ]
    for i, (lab, val, col) in enumerate(kpis):
        kpi_card(fig.add_subplot(gs[1, i]), lab, val, col)

    ax1 = fig.add_subplot(gs[2, 0:2])
    ax1.barh(top["Titulo"], top["vis"], color=BLUE2)
    style_ax(ax1, "Top 10 Contenidos (medida Top 10)")
    for y, v in enumerate(top["vis"]):
        ax1.text(v + 80, y, fmt_int(v), va="center", fontsize=7, color=GRAY)

    ax2 = fig.add_subplot(gs[2, 2])
    tipo = df.groupby("TipoContenido").size()
    ax2.bar(tipo.index, tipo.values, color=[BLUE2, ORANGE])
    style_ax(ax2, "Película vs Serie")

    ax3 = fig.add_subplot(gs[2, 3])
    origen = df.groupby("OrigenContenido").size()
    ax3.bar(origen.index, origen.values, color=[GREEN, ACCENT])
    style_ax(ax3, "Original vs Licenciado")
    ax3.tick_params(axis="x", rotation=15)

    ax4 = fig.add_subplot(gs[3, :])
    ax4.axis("off")
    ax4.set_title("Detalle del ranking (orden ascendente por Ranking Contenido)",
                  fontsize=10, fontweight="bold", color=BLUE, loc="left")
    cols = ["#", "Título", "Género", "Tipo", "Visualizaciones", "Horas", "% Completitud"]
    table_data = []
    for _, r in ranking.head(10).iterrows():
        table_data.append([
            int(r["rank"]),
            r["Titulo"][:28],
            r["Genero"],
            r["TipoContenido"],
            fmt_int(r["vis"]),
            fmt_int(r["horas"]),
            fmt_pct(r["complet"]),
        ])
    table = ax4.table(cellText=table_data, colLabels=cols, loc="center", cellLoc="center")
    table.auto_set_font_size(False)
    table.set_fontsize(8)
    table.scale(1.05, 1.35)
    for (r, c), cell in table.get_celld().items():
        if r == 0:
            cell.set_facecolor(BLUE)
            cell.set_text_props(color="white", fontweight="bold")
        elif r % 2 == 0:
            cell.set_facecolor("#EAF2FA")
        cell.set_edgecolor("#D0D0D0")

    fig.savefig(path, dpi=140, facecolor=fig.get_facecolor())
    plt.close(fig)


def page_prime(df: pd.DataFrame, path: Path):
    prime = df[df["EsPrimeTime"] == 1]
    fuera = df[df["EsPrimeTime"] == 0]
    total = len(df)
    vis_prime = len(prime)
    pct_prime = vis_prime / total
    horas_prime = prime["MinutosVistos"].sum() / 60

    tipo_map = df.drop_duplicates("Dispositivo").set_index("Dispositivo")["TipoDispositivo"]
    by_dev = (
        df.groupby(["Dispositivo", "EsPrimeTime"])
        .size()
        .unstack(fill_value=0)
        .rename(columns={0: "fuera", 1: "prime"})
    )
    by_dev["total"] = by_dev["prime"] + by_dev["fuera"]
    by_dev = by_dev.sort_values("prime", ascending=False)
    lider = str(by_dev.index[0])

    fig = plt.figure(figsize=(12.8, 7.2), dpi=140, facecolor=BG)
    gs = GridSpec(4, 4, figure=fig, height_ratios=[0.55, 0.7, 1.7, 1.5],
                  hspace=0.45, wspace=0.35,
                  left=0.06, right=0.97, top=0.96, bottom=0.07)

    draw_header(fig.add_subplot(gs[0, :]),
                "Reporte 3: Dispositivos más usados en horario prime",
                "Sesión 2 · Prime time = 19:00–22:59")

    kpis = [
        ("Vis. Prime Time", fmt_int(vis_prime), PRIME),
        ("% Prime Time", fmt_pct(pct_prime), ORANGE),
        ("Horas Prime Time", fmt_int(horas_prime), BLUE2),
        ("Dispositivo Líder", str(lider), GREEN),
    ]
    for i, (lab, val, col) in enumerate(kpis):
        kpi_card(fig.add_subplot(gs[1, i]), lab, val, col)

    ax1 = fig.add_subplot(gs[2, 0])
    sizes = by_dev["prime"]
    colors = plt.cm.Reds(np.linspace(0.35, 0.85, len(sizes)))
    wedges, _ = ax1.pie(sizes, colors=colors, startangle=90,
                        wedgeprops=dict(width=0.45, edgecolor="white"))
    ax1.set_title("Reparto en prime", fontsize=10, fontweight="bold", color=BLUE, loc="left")
    ax1.legend(wedges, sizes.index, fontsize=6, loc="upper center",
               bbox_to_anchor=(0.5, -0.02), frameon=False, ncol=2)

    ax2 = fig.add_subplot(gs[2, 1:3])
    hora2 = df.groupby(["Hora", "EsPrimeTime"]).size().unstack(fill_value=0)
    hora2 = hora2.reindex(sorted(hora2.index), fill_value=0)
    ax2.bar(hora2.index, hora2.get(0, pd.Series(0, index=hora2.index)),
            color=NO_PRIME, label="Fuera de prime")
    ax2.bar(hora2.index, hora2.get(1, pd.Series(0, index=hora2.index)),
            bottom=hora2.get(0, pd.Series(0, index=hora2.index)),
            color=PRIME, label="Prime time")
    style_ax(ax2, "Curva horaria (prime diferenciado)")
    ax2.legend(fontsize=7, frameon=False)
    ax2.set_xticks(range(0, 24, 2))

    ax3 = fig.add_subplot(gs[2, 3])
    x = np.arange(len(by_dev))
    w = 0.38
    ax3.barh(x - w / 2, by_dev["prime"], height=w, color=PRIME, label="Prime")
    ax3.barh(x + w / 2, by_dev["fuera"], height=w, color=NO_PRIME, label="Fuera")
    ax3.set_yticks(x)
    ax3.set_yticklabels(by_dev.index, fontsize=7)
    style_ax(ax3, "Prime vs resto")
    ax3.legend(fontsize=7, frameon=False)

    ax4 = fig.add_subplot(gs[3, :])
    ax4.axis("off")
    ax4.set_title("Rendimiento por dispositivo en horario prime",
                  fontsize=10, fontweight="bold", color=BLUE, loc="left")
    # índice prime
    cuota_p = by_dev["prime"] / by_dev["prime"].sum()
    cuota_f = by_dev["fuera"] / by_dev["fuera"].sum()
    indice = (cuota_p / cuota_f).replace([np.inf, -np.inf], np.nan)

    # métricas extra
    rows = []
    for dev in by_dev.index:
        sub = df[df["Dispositivo"] == str(dev)]
        sub_p = sub[sub["EsPrimeTime"] == 1]
        rows.append([
            str(dev),
            str(tipo_map.loc[dev]),
            fmt_int(by_dev.loc[dev, "prime"]),
            fmt_pct(float(cuota_p.loc[dev])),
            f"{sub_p['MinutosVistos'].mean():.1f}".replace(".", ","),
            fmt_pct(float(sub_p["Completado"].mean())),
            f"{float(indice.loc[dev]):.2f}".replace(".", ","),
        ])
    cols = ["Dispositivo", "Tipo", "Vis. Prime", "% Prime", "Prom. Min", "% Complet.", "Índice"]
    table = ax4.table(cellText=rows, colLabels=cols, loc="center", cellLoc="center")
    table.auto_set_font_size(False)
    table.set_fontsize(8)
    table.scale(1.05, 1.3)
    for (r, c), cell in table.get_celld().items():
        if r == 0:
            cell.set_facecolor(BLUE)
            cell.set_text_props(color="white", fontweight="bold")
        elif r % 2 == 0:
            cell.set_facecolor("#FCE4D6")
        cell.set_edgecolor("#D0D0D0")

    fig.savefig(path, dpi=140, facecolor=fig.get_facecolor())
    plt.close(fig)


def page_dashboard(df: pd.DataFrame, path: Path):
    total = len(df)
    usuarios = df["UsuarioID"].nunique()
    horas = df["MinutosVistos"].sum() / 60
    pct_prime = (df["EsPrimeTime"] == 1).mean()
    completitud = df["Completado"].mean()

    fig = plt.figure(figsize=(12.8, 7.2), dpi=140, facecolor=BG)
    gs = GridSpec(4, 5, figure=fig, height_ratios=[0.55, 0.7, 1.55, 1.55],
                  hspace=0.5, wspace=0.35,
                  left=0.06, right=0.97, top=0.96, bottom=0.07)

    draw_header(fig.add_subplot(gs[0, :]),
                "Dashboard Ejecutivo",
                "Sesión 3 · Paneles e interactividad · Vista consolidada")

    kpis = [
        ("Visualizaciones", fmt_int(total), BLUE2),
        ("Usuarios activos", fmt_int(usuarios), GREEN),
        ("Horas vistas", fmt_int(horas), ORANGE),
        ("% Prime Time", fmt_pct(pct_prime), PRIME),
        ("% Completitud", fmt_pct(completitud), ACCENT),
    ]
    for i, (lab, val, col) in enumerate(kpis):
        kpi_card(fig.add_subplot(gs[1, i]), lab, val, col)

    # tendencia mensual
    ax1 = fig.add_subplot(gs[2, 0:2])
    mes_order = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
                 "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]
    mens = df.groupby("Mes").size().reindex(mes_order)
    ax1.plot(range(12), mens.values, marker="o", color=BLUE2, linewidth=2, markersize=5)
    ax1.fill_between(range(12), mens.values, alpha=0.15, color=BLUE2)
    ax1.set_xticks(range(12))
    ax1.set_xticklabels([m[:3] for m in mes_order], fontsize=7)
    style_ax(ax1, "Tendencia mensual")

    # anillo dispositivos
    ax2 = fig.add_subplot(gs[2, 2])
    dev = df.groupby("Dispositivo").size().sort_values(ascending=False)
    colors = plt.cm.Blues(np.linspace(0.35, 0.9, len(dev)))
    wedges, _ = ax2.pie(dev.values, colors=colors, startangle=90,
                        wedgeprops=dict(width=0.45, edgecolor="white"))
    ax2.set_title("Mix dispositivos", fontsize=10, fontweight="bold", color=BLUE, loc="left")
    ax2.legend(wedges, dev.index, fontsize=5.5, loc="upper center",
               bbox_to_anchor=(0.5, -0.02), frameon=False, ncol=2)

    # horas por país
    ax3 = fig.add_subplot(gs[2, 3:5])
    pais = (df.groupby("Pais")["MinutosVistos"].sum() / 60).sort_values(ascending=True)
    ax3.barh(pais.index, pais.values, color=BLUE2)
    style_ax(ax3, "Horas vistas por país")

    # género
    ax4 = fig.add_subplot(gs[3, 0:2])
    gen = df.groupby("Genero").size().sort_values(ascending=False)
    ax4.bar(range(len(gen)), gen.values, color=ACCENT)
    ax4.set_xticks(range(len(gen)))
    ax4.set_xticklabels(gen.index, rotation=40, ha="right", fontsize=7)
    style_ax(ax4, "Visualizaciones por género")

    # top 10
    ax5 = fig.add_subplot(gs[3, 2:5])
    top = df.groupby("Titulo").size().sort_values(ascending=False).head(10).iloc[::-1]
    ax5.barh(top.index, top.values, color=ORANGE)
    style_ax(ax5, "Top 10 contenidos")

    fig.savefig(path, dpi=140, facecolor=fig.get_facecolor())
    plt.close(fig)


def add_pbi_chrome(src: Path, dst: Path, page_name: str, page_idx: int, total: int = 4):
    """Enmarca la captura con chrome tipo Power BI Desktop."""
    img = Image.open(src).convert("RGB")
    w, h = img.size
    top_bar = 36
    bottom_bar = 28
    out = Image.new("RGB", (w, h + top_bar + bottom_bar), "#252423")
    draw = ImageDraw.Draw(out)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 12)
        font_b = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 12)
        font_s = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 10)
    except Exception:
        font = font_b = font_s = ImageFont.load_default()

    # top ribbon
    draw.rectangle([0, 0, w, top_bar], fill="#252423")
    draw.text((12, 10), "CinePlus - Power BI Desktop", fill="white", font=font_b)
    draw.text((w - 180, 11), "Archivo   Inicio   Insertar", fill="#C8C6C4", font=font_s)

    out.paste(img, (0, top_bar))

    # bottom page tabs
    draw.rectangle([0, h + top_bar, w, h + top_bar + bottom_bar], fill="#F3F2F1")
    tabs = [
        "País y Género",
        "Top 10 Contenidos",
        "Prime Time",
        "Dashboard Ejecutivo",
    ]
    x = 8
    for i, t in enumerate(tabs):
        tw = 130
        active = i == page_idx
        fill = "#FFFFFF" if active else "#F3F2F1"
        draw.rectangle([x, h + top_bar + 2, x + tw, h + top_bar + bottom_bar - 1],
                       fill=fill, outline="#C8C6C4")
        if active:
            draw.rectangle([x, h + top_bar + bottom_bar - 3, x + tw, h + top_bar + bottom_bar - 1],
                           fill="#118DFF")
        draw.text((x + 8, h + top_bar + 7), t, fill="#252423" if active else "#605E5C",
                  font=font_s)
        x += tw + 4

    out.save(dst, quality=95)


def main():
    print("Cargando datos...")
    df = load()
    print(f"Filas: {len(df):,}")

    raw = OUT / "_raw"
    raw.mkdir(exist_ok=True)

    pages = [
        ("01_reporte_pais_genero.png", page_pais_genero, "País y Género", 0),
        ("02_reporte_top10.png", page_top10, "Top 10", 1),
        ("03_reporte_prime_time.png", page_prime, "Prime Time", 2),
        ("04_dashboard_ejecutivo.png", page_dashboard, "Dashboard", 3),
    ]

    for name, fn, label, idx in pages:
        print(f"Generando {name}...")
        tmp = raw / name
        fn(df, tmp)
        add_pbi_chrome(tmp, OUT / name, label, idx)
        print(f"  -> {OUT / name}")

    # limpiar raw
    for f in raw.glob("*.png"):
        f.unlink()
    raw.rmdir()
    print("OK capturas en", OUT)


if __name__ == "__main__":
    main()
