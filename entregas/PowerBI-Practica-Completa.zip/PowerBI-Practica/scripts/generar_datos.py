# -*- coding: utf-8 -*-
"""
CinePlus - Generador del Data Warehouse (esquema estrella)
Practica Power BI + SSAS  |  Estudiante: Andy Chafla

Genera las dimensiones y la tabla de hechos que replican el contenido
del cubo multidimensional CinePlus_Cubo.

Salida: ../datos/*.csv  (UTF-8 con BOM para compatibilidad con Excel/Power BI)
"""

import csv
import os
import random
from datetime import date, timedelta

random.seed(20260101)  # reproducible: misma data en cada ejecucion

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(BASE, "datos")
os.makedirs(OUT, exist_ok=True)


def escribir(nombre, cabeceras, filas):
    ruta = os.path.join(OUT, nombre)
    with open(ruta, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(cabeceras)
        w.writerows(filas)
    print(f"  {nombre:<28} {len(filas):>8,} filas")


# ---------------------------------------------------------------- DIM PAIS
PAISES = [
    # id, pais, codigo, region, moneda, peso_mercado
    (1,  "Ecuador",            "EC", "Andina",        "USD", 0.10),
    (2,  "Colombia",           "CO", "Andina",        "COP", 0.14),
    (3,  "Peru",               "PE", "Andina",        "PEN", 0.09),
    (4,  "Chile",              "CL", "Cono Sur",      "CLP", 0.08),
    (5,  "Argentina",          "AR", "Cono Sur",      "ARS", 0.12),
    (6,  "Mexico",             "MX", "Norteamerica",  "MXN", 0.18),
    (7,  "Espana",             "ES", "Europa",        "EUR", 0.11),
    (8,  "Brasil",             "BR", "Cono Sur",      "BRL", 0.10),
    (9,  "Costa Rica",         "CR", "Centroamerica", "CRC", 0.04),
    (10, "Republica Dominicana","DO","Caribe",        "DOP", 0.04),
]
escribir(
    "DimPais.csv",
    ["PaisID", "Pais", "CodigoISO", "Region", "Moneda"],
    [(p[0], p[1], p[2], p[3], p[4]) for p in PAISES],
)

# -------------------------------------------------------------- DIM GENERO
GENEROS = [
    # id, genero, categoria, peso
    (1,  "Accion",       "Entretenimiento", 0.15),
    (2,  "Drama",        "Narrativo",       0.14),
    (3,  "Comedia",      "Entretenimiento", 0.13),
    (4,  "Terror",       "Entretenimiento", 0.07),
    (5,  "Ciencia Ficcion","Narrativo",     0.09),
    (6,  "Documental",   "Educativo",       0.06),
    (7,  "Romance",      "Narrativo",       0.08),
    (8,  "Animacion",    "Familiar",        0.10),
    (9,  "Suspenso",     "Narrativo",       0.11),
    (10, "Infantil",     "Familiar",        0.07),
]
escribir(
    "DimGenero.csv",
    ["GeneroID", "Genero", "CategoriaGenero"],
    [(g[0], g[1], g[2]) for g in GENEROS],
)

# ---------------------------------------------------------- DIM DISPOSITIVO
DISPOSITIVOS = [
    # id, dispositivo, tipo, so, pantalla, peso_general, sesgo_prime
    (1, "Smart TV",         "Television", "Tizen/WebOS", "Grande",  0.26, 1.85),
    (2, "Telefono Movil",   "Movil",      "Android/iOS", "Pequena", 0.28, 0.55),
    (3, "Tablet",           "Movil",      "Android/iOS", "Mediana", 0.11, 0.80),
    (4, "Laptop",           "Computador", "Windows/Mac", "Mediana", 0.14, 0.70),
    (5, "Consola de Juegos","Television", "PlayStation/Xbox","Grande",0.08, 1.60),
    (6, "TV Box / Stick",   "Television", "Android TV/FireTV","Grande",0.09, 1.70),
    (7, "Navegador Web",    "Computador", "Multiplataforma","Mediana",0.04, 0.65),
]
escribir(
    "DimDispositivo.csv",
    ["DispositivoID", "Dispositivo", "TipoDispositivo", "SistemaOperativo", "TamanoPantalla"],
    [(d[0], d[1], d[2], d[3], d[4]) for d in DISPOSITIVOS],
)

# ----------------------------------------------------------- DIM CONTENIDO
TITULOS = {
    1: ["Codigo Rojo", "La Ultima Frontera", "Furia de Acero", "Operacion Condor",
        "Impacto Cero", "Cazadores del Alba", "Linea de Fuego", "Protocolo Titan"],
    2: ["Raices de Sal", "El Peso del Silencio", "Cartas sin Enviar", "Mar Adentro del Alma",
        "La Casa de los Abuelos", "Cicatrices", "Invierno en Quito", "Lo que el Rio Guarda"],
    3: ["Vecinos Imposibles", "Mi Suegra y Yo", "Plan B", "El Gran Enredo",
        "Oficina 303", "Vacaciones Forzadas", "Dos Bodas y un Perro", "Pasante de Lujo"],
    4: ["La Casa de Enfrente", "Ritual Nocturno", "El Octavo Piso", "Niebla",
        "Susurros en el Sotano", "Marca del Cuervo"],
    5: ["Orbita Final", "Proyecto Helios", "Memoria Artificial", "Los Hijos de Marte",
        "Singularidad", "Eco del Vacio", "Terraforma"],
    6: ["Galapagos Profundo", "Andes: Techo del Mundo", "Amazonia Viva",
        "Mentes Brillantes", "La Ruta del Cacao", "Ciudades Invisibles"],
    7: ["Dos Inviernos", "Postales de Paris", "El Verano que Volviste",
        "Contigo en Cuenca", "Tarde o Temprano", "Nota Azul"],
    8: ["Los Guardianes del Bosque", "Chispa", "Reino de Papel", "Luna y el Dragon",
        "Aventura Polar", "El Pequeno Inventor", "Colores del Viento"],
    9: ["Punto Ciego", "La Testigo", "Rastro Falso", "Caso 47",
        "Doble Identidad", "El Ultimo Tren", "Trampa Perfecta", "Sombra Legal"],
    10:["Academia Arcoiris", "Pipo y Tula", "El Club de los Valientes",
        "Granja Feliz", "Mundo Burbuja"],
}

contenidos = []
cid = 0
for gid, lista in TITULOS.items():
    for t in lista:
        cid += 1
        tipo = random.choices(["Pelicula", "Serie"], weights=[0.55, 0.45])[0]
        if tipo == "Serie":
            temporadas = random.randint(1, 5)
            episodios = temporadas * random.randint(6, 12)
            duracion = random.randint(38, 58)
        else:
            temporadas, episodios = 0, 0
            duracion = random.randint(88, 155)
        clasif = random.choices(
            ["TP", "+7", "+12", "+16", "+18"],
            weights=[0.18, 0.14, 0.26, 0.28, 0.14])[0]
        if gid in (8, 10):
            clasif = random.choice(["TP", "+7"])
        if gid == 4:
            clasif = random.choice(["+16", "+18"])
        contenidos.append((
            cid, t, gid, tipo, random.randint(2016, 2025), duracion,
            temporadas, episodios, clasif,
            random.choices(["Original CinePlus", "Licenciado"], weights=[0.35, 0.65])[0],
        ))

escribir(
    "DimContenido.csv",
    ["ContenidoID", "Titulo", "GeneroID", "TipoContenido", "AnioEstreno",
     "DuracionMin", "Temporadas", "Episodios", "Clasificacion", "OrigenContenido"],
    contenidos,
)

# popularidad: distribucion long-tail para que el Top 10 sea nitido
pop = {}
calidad = {}
for c in contenidos:
    base = random.paretovariate(1.35)
    if c[9] == "Original CinePlus":
        base *= 1.6
    if c[4] >= 2023:
        base *= 1.45
    pop[c[0]] = base
    # "enganche" propio de cada titulo: unos retienen mucho mas que otros
    q = random.betavariate(2.6, 2.6)
    if c[9] == "Original CinePlus":
        q = min(1.0, q + 0.12)
    if c[3] == "Serie":
        q = min(1.0, q + 0.06)      # los episodios se terminan mas
    calidad[c[0]] = 0.42 + 0.46 * q  # prob. de sesion completada: 0.42 a 0.88

# ------------------------------------------------------------- DIM USUARIO
PLANES = [("Basico", 0.38), ("Estandar", 0.40), ("Premium", 0.22)]
usuarios = []
for uid in range(1, 3001):
    pais = random.choices([p[0] for p in PAISES], weights=[p[5] for p in PAISES])[0]
    plan = random.choices([p[0] for p in PLANES], weights=[p[1] for p in PLANES])[0]
    edad = random.choices(
        [random.randint(13, 17), random.randint(18, 24), random.randint(25, 34),
         random.randint(35, 44), random.randint(45, 54), random.randint(55, 70)],
        weights=[0.08, 0.22, 0.27, 0.21, 0.14, 0.08])[0]
    rango = ("13-17" if edad < 18 else "18-24" if edad < 25 else "25-34"
             if edad < 35 else "35-44" if edad < 45 else "45-54" if edad < 55 else "55+")
    alta = date(2023, 1, 1) + timedelta(days=random.randint(0, 1000))
    usuarios.append((
        uid, f"USR{uid:05d}", pais, plan, edad, rango,
        random.choice(["Femenino", "Masculino", "No especifica"]),
        alta.isoformat(),
        random.choices(["Activo", "Activo", "Activo", "Pausado"], weights=[.3,.3,.3,.1])[0],
    ))

escribir(
    "DimUsuario.csv",
    ["UsuarioID", "CodigoUsuario", "PaisID", "TipoPlan", "Edad", "RangoEtario",
     "Genero", "FechaRegistro", "EstadoCuenta"],
    usuarios,
)

# -------------------------------------------------------------- DIM TIEMPO
MESES = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio",
         "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]
DIAS = ["Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo"]

tiempo = []
d = date(2025, 1, 1)
fin = date(2025, 12, 31)
while d <= fin:
    key = int(d.strftime("%Y%m%d"))
    trim = (d.month - 1) // 3 + 1
    finde = d.weekday() >= 5
    tiempo.append((
        key, d.isoformat(), d.year, f"{d.year}-S{trim}" if False else f"T{trim}",
        f"{d.year}-T{trim}", d.month, MESES[d.month - 1],
        f"{d.year}-{d.month:02d}", d.day, DIAS[d.weekday()], d.weekday() + 1,
        int(d.strftime("%V")), "Fin de Semana" if finde else "Entre Semana",
    ))
    d += timedelta(days=1)

escribir(
    "DimTiempo.csv",
    ["FechaKey", "Fecha", "Anio", "Trimestre", "AnioTrimestre", "NumeroMes",
     "Mes", "AnioMes", "Dia", "NombreDia", "NumeroDia", "SemanaAnio", "TipoDia"],
    tiempo,
)

# --------------------------------------------------------------- DIM HORA
# Franja PRIME TIME = 19:00 a 22:59 (requisito del Reporte 3)
hora_rows = []
peso_hora = []
for h in range(24):
    if h < 6:
        franja, prime, orden = "Madrugada", 0, 1
        w = 0.4
    elif h < 12:
        franja, prime, orden = "Manana", 0, 2
        w = 0.8
    elif h < 19:
        franja, prime, orden = "Tarde", 0, 3
        w = 1.55
    elif h < 23:
        franja, prime, orden = "Prime Time", 1, 4
        w = 2.45
    else:
        franja, prime, orden = "Noche", 0, 5
        w = 1.1
    hora_rows.append((h, f"{h:02d}:00", franja, orden, prime,
                      "Si" if prime else "No",
                      f"{h:02d}:00 - {h:02d}:59"))
    peso_hora.append(w)

escribir(
    "DimHora.csv",
    ["HoraKey", "Hora", "FranjaHoraria", "OrdenFranja", "EsPrimeTime",
     "PrimeTimeDesc", "RangoHora"],
    hora_rows,
)

# --------------------------------------------------- FACT VISUALIZACIONES
print("\n  Generando tabla de hechos...")

pais_ids = [p[0] for p in PAISES]
usuarios_por_pais = {}
for u in usuarios:
    usuarios_por_pais.setdefault(u[2], []).append(u[0])

cont_por_genero = {}
for c in contenidos:
    cont_por_genero.setdefault(c[2], []).append(c[0])
cont_dur = {c[0]: c[5] for c in contenidos}
cont_tipo = {c[0]: c[3] for c in contenidos}
cont_gen = {c[0]: c[2] for c in contenidos}

# afinidad de genero por pais: da variacion real al Reporte 1
afinidad = {}
for pid in pais_ids:
    afinidad[pid] = {g[0]: g[3] * random.uniform(0.55, 1.75) for g in GENEROS}

dev_ids = [d[0] for d in DISPOSITIVOS]
dev_peso = [d[5] for d in DISPOSITIVOS]
dev_prime = {d[0]: d[6] for d in DISPOSITIVOS}

fechas_key = [t[0] for t in tiempo]
# estacionalidad: picos en vacaciones (jul-ago) y diciembre
peso_fecha = []
for t in tiempo:
    mes = t[5]
    w = 1.0
    if mes in (7, 8):
        w = 1.30
    elif mes == 12:
        w = 1.35
    elif mes in (2, 3):
        w = 0.92
    if t[12] == "Fin de Semana":
        w *= 1.55
    peso_fecha.append(w)

horas = list(range(24))

N = 180000
hechos = []
for i in range(1, N + 1):
    pid = random.choices(pais_ids, weights=[p[5] for p in PAISES])[0]
    uid = random.choice(usuarios_por_pais[pid])

    # genero segun afinidad del pais
    af = afinidad[pid]
    gid = random.choices(list(af.keys()), weights=list(af.values()))[0]
    candidatos = cont_por_genero[gid]
    cont = random.choices(candidatos, weights=[pop[c] for c in candidatos])[0]

    fkey = random.choices(fechas_key, weights=peso_fecha)[0]
    hkey = random.choices(horas, weights=peso_hora)[0]
    es_prime = 1 if 19 <= hkey < 23 else 0

    # el dispositivo depende de la franja: TV manda en prime, movil en el dia
    if es_prime:
        pesos = [dev_peso[j] * dev_prime[dev_ids[j]] for j in range(len(dev_ids))]
    else:
        pesos = [dev_peso[j] / max(dev_prime[dev_ids[j]], 0.01) ** 0.45
                 for j in range(len(dev_ids))]
    did = random.choices(dev_ids, weights=pesos)[0]

    dur = cont_dur[cont]
    # mezcla realista: la probabilidad de terminar depende del enganche del titulo
    if random.random() < calidad[cont]:
        pct = random.betavariate(11.0, 1.25)   # sesion completada
    else:
        pct = random.betavariate(1.7, 3.0)     # abandono temprano
    pct = min(1.0, max(0.02, pct))
    if did in (2, 3) and not es_prime:
        pct *= random.uniform(0.72, 0.98)      # movil fuera de prime: mas abandono
    if did in (1, 5, 6) and es_prime:
        pct = min(1.0, pct * random.uniform(1.02, 1.15))
    minutos = max(1, round(dur * pct))
    completado = 1 if pct >= 0.85 else 0
    valoracion = ""
    if random.random() < 0.22:                  # solo 22% califica
        base_val = 3.2 + (pop[cont] ** 0.12) * 0.45
        valoracion = max(1, min(5, round(random.gauss(base_val, 0.85))))

    hechos.append((
        i, fkey, hkey, uid, cont, did, pid, gid,
        minutos, round(pct * 100, 2), completado, es_prime, 1, valoracion,
    ))

escribir(
    "FactVisualizaciones.csv",
    ["VisualizacionID", "FechaKey", "HoraKey", "UsuarioID", "ContenidoID",
     "DispositivoID", "PaisID", "GeneroID", "MinutosVistos", "PorcentajeVisto",
     "Completado", "EsPrimeTime", "Reproducciones", "Valoracion"],
    hechos,
)

# ------------------------------------------------------------- VALIDACION
print("\n  --- Validacion ---")
tot_min = sum(h[8] for h in hechos)
prime = sum(1 for h in hechos if h[11] == 1)
comp = sum(h[10] for h in hechos)
print(f"  Visualizaciones .......... {len(hechos):,}")
print(f"  Usuarios unicos .......... {len({h[3] for h in hechos}):,}")
print(f"  Minutos vistos ........... {tot_min:,}  ({tot_min/60:,.0f} horas)")
print(f"  % Prime Time ............. {prime/len(hechos)*100:.1f}%")
print(f"  % Completitud ............ {comp/len(hechos)*100:.1f}%")

top = {}
for h in hechos:
    top[h[4]] = top.get(h[4], 0) + 1
nombres = {c[0]: c[1] for c in contenidos}
print("\n  Top 5 contenidos:")
for c, n in sorted(top.items(), key=lambda x: -x[1])[:5]:
    print(f"    {nombres[c]:<28} {n:>7,}")
print("\n  Listo.")
