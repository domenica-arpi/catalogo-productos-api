# Hallazgos del analisis — CinePlus

Cifras calculadas directamente sobre `datos/FactVisualizaciones.csv`.
Deben coincidir exactamente con las medidas DAX del modelo.

## Indicadores globales

| Indicador | Valor |
|---|---|
| Total visualizaciones | 180.000 |
| Usuarios unicos | 3.000 |
| Contenidos reproducidos | 69 |
| Minutos vistos | 10.048.194 |
| Horas vistas | 167.469 |
| Promedio min. por sesion | 55.8 |
| % completitud | 43.0% |
| % prime time | 33.9% |
| Valoracion promedio | 3.73 (39.233 sesiones valoradas) |

## Reporte 1 — Visualizaciones por pais y genero

| Pais | Region | Visualizaciones | % | Horas vistas |
|---|---|---:|---:|---:|
| Mexico | Norteamerica | 32.281 | 17.9% | 30.205 |
| Colombia | Andina | 24.999 | 13.9% | 23.562 |
| Argentina | Cono Sur | 21.726 | 12.1% | 19.902 |
| Espana | Europa | 19.917 | 11.1% | 18.602 |
| Brasil | Cono Sur | 18.074 | 10.0% | 16.456 |
| Ecuador | Andina | 18.041 | 10.0% | 16.955 |
| Peru | Andina | 16.198 | 9.0% | 14.955 |
| Chile | Cono Sur | 14.417 | 8.0% | 13.543 |
| Republica Dominicana | Caribe | 7.202 | 4.0% | 6.825 |
| Costa Rica | Centroamerica | 7.145 | 4.0% | 6.459 |

| Genero | Visualizaciones | % |
|---|---:|---:|
| Accion | 26.873 | 14.9% |
| Drama | 23.272 | 12.9% |
| Comedia | 22.592 | 12.6% |
| Suspenso | 20.468 | 11.4% |
| Animacion | 16.151 | 9.0% |
| Ciencia Ficcion | 15.967 | 8.9% |
| Terror | 15.624 | 8.7% |
| Romance | 14.177 | 7.9% |
| Infantil | 12.962 | 7.2% |
| Documental | 11.914 | 6.6% |

**Genero lider en cada pais** (lo que el grafico de barras por si solo no revela):

| Pais | Genero lider | Visualizaciones | Cuota dentro del pais |
|---|---|---:|---:|
| Mexico | Accion | 4.900 | 15.2% |
| Colombia | Accion | 4.872 | 19.5% |
| Argentina | Suspenso | 3.270 | 15.1% |
| Espana | Comedia | 4.298 | 21.6% |
| Brasil | Accion | 3.449 | 19.1% |
| Ecuador | Accion | 3.811 | 21.1% |
| Peru | Drama | 2.503 | 15.5% |
| Chile | Accion | 2.893 | 20.1% |
| Republica Dominicana | Accion | 1.191 | 16.5% |
| Costa Rica | Suspenso | 1.204 | 16.9% |

## Reporte 2 — Top 10 contenidos mas vistos

| # | Titulo | Genero | Tipo | Visualizaciones | Horas | % completitud |
|---:|---|---|---|---:|---:|---:|
| 1 | Trampa Perfecta | Suspenso | Serie | 13.220 | 7.413 | 52.1% |
| 2 | Cartas sin Enviar | Drama | Serie | 10.068 | 5.010 | 41.6% |
| 3 | Dos Inviernos | Romance | Serie | 8.574 | 5.727 | 49.3% |
| 4 | Niebla | Terror | Pelicula | 7.756 | 8.987 | 39.1% |
| 5 | Furia de Acero | Accion | Pelicula | 6.440 | 10.899 | 38.4% |
| 6 | Aventura Polar | Animacion | Pelicula | 4.893 | 5.173 | 41.7% |
| 7 | Mi Suegra y Yo | Comedia | Pelicula | 4.825 | 8.152 | 40.6% |
| 8 | Protocolo Titan | Accion | Serie | 4.739 | 2.851 | 42.5% |
| 9 | Cazadores del Alba | Accion | Pelicula | 4.511 | 6.416 | 37.7% |
| 10 | Colores del Viento | Animacion | Serie | 4.182 | 2.505 | 38.7% |

El Top 10 concentra **69.208 visualizaciones**, el **38.4%** del consumo total, sobre un catalogo de 69 titulos. Los 10 titulos de la cola suman 6.919.

## Reporte 3 — Dispositivos en horario prime (19:00–22:59)

| Dispositivo | Tipo | Prime time | % del prime | Fuera de prime | Indice prime |
|---|---|---:|---:|---:|---:|
| Smart TV | Television | 26.082 | 42.7% | 22.516 | 2.26 |
| Telefono Movil | Movil | 8.356 | 13.7% | 42.261 | 0.39 |
| TV Box / Stick | Television | 8.349 | 13.7% | 8.209 | 1.98 |
| Consola de Juegos | Television | 6.841 | 11.2% | 7.463 | 1.79 |
| Laptop | Computador | 5.317 | 8.7% | 19.063 | 0.54 |
| Tablet | Movil | 4.647 | 7.6% | 13.835 | 0.65 |
| Navegador Web | Computador | 1.457 | 2.4% | 5.604 | 0.51 |

*Indice prime = cuota del dispositivo dentro del horario estelar dividida por su cuota fuera de el. Mayor que 1 significa sobre-representado en prime time.*

Hora pico: **19:00** con 15.290 visualizaciones. Hora valle: **05:00** con 2.366. La franja prime concentra el **33.9%** del consumo en solo 4 de las 24 horas (seria 16.7% si el consumo se repartiera de forma uniforme).

| Franja | Visualizaciones | % |
|---|---:|---:|
| Tarde | 67.744 | 37.6% |
| Prime Time | 61.049 | 33.9% |
| Manana | 29.782 | 16.5% |
| Madrugada | 14.675 | 8.2% |
| Noche | 6.750 | 3.8% |

## Estacionalidad mensual (dashboard)

| Mes | Visualizaciones | % |
|---|---:|---:|
| Enero | 14.017 | 7.8% |
| Febrero | 11.643 | 6.5% |
| Marzo | 13.614 | 7.6% |
| Abril | 13.875 | 7.7% |
| Mayo | 14.279 | 7.9% |
| Junio | 13.954 | 7.8% |
| Julio | 18.082 | 10.0% |
| Agosto | 19.092 | 10.6% |
| Septiembre | 13.707 | 7.6% |
| Octubre | 14.261 | 7.9% |
| Noviembre | 14.237 | 7.9% |
| Diciembre | 19.239 | 10.7% |

Pico en **Diciembre** (19.239) y minimo en **Febrero** (11.643): una amplitud del 65% entre el mejor y el peor mes.

Fin de semana: 68.632 visualizaciones en 104 dias (660 por dia). Entre semana: 111.368 en 261 dias (427 por dia).
