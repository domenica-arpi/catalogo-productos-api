# Práctica: Power BI sobre el cubo SSAS `CinePlus_Cubo`

**Estudiante:** Andy Chafla
**Fecha:** 18 de noviembre de 2026
**Entregable:** modelo semántico + 3 reportes ejecutivos + dashboard interactivo

---

## 0. Alcance real de la entrega (léase primero)

La práctica parte del supuesto de que el cubo `CinePlus_Cubo` ya existe y está
procesado en una instancia de Analysis Services. **En el equipo de trabajo no hay
instancia SSAS ni motor SQL Server instalados** (se verificó: solo existen los
drivers `MSOLEDBSQL19`, `MSODBCSQL17/18` y un servicio MySQL 8.0). Tampoco existía
ningún archivo previo del cubo en el disco.

Frente a eso, la entrega cubre los dos lados del problema:

| Entregable | Estado |
|---|---|
| Data Warehouse `CinePlus_DW` completo (8 tablas, 180.000 hechos) | **Construido y verificado** |
| Modelo semántico equivalente al cubo, con sus dimensiones y medidas | **Construido y validado** |
| Reporte 1, Reporte 2, Reporte 3 y dashboard interactivo | **Construidos (4 páginas, 55 visuales)** |
| Scripts para recrear el DW y el cubo en SQL Server + SSAS | **Entregados, no ejecutados** (falta el motor) |
| Conexión en vivo de Power BI contra SSAS | **Documentada, no ejecutada** (falta el servidor) |

El modelo tabular entregado reproduce la **misma estructura dimensional y las
mismas medidas** que tendría el cubo multidimensional, de modo que los reportes
son idénticos en ambos escenarios: si mañana se levanta la instancia SSAS, solo
cambia el origen de datos, no el diseño de los reportes.

---

## 1. Arquitectura de la solución

```
  CSV (/datos)  ──►  CinePlus_DW (SQL Server)  ──►  CinePlus_Cubo (SSAS)  ──►  Power BI
       │                                                                          ▲
       └──────────────────  ruta implementada en esta práctica  ───────────────────┘
```

### Modelo dimensional (esquema estrella)

`FactVisualizaciones` es la tabla de hechos; el grano es **una fila por
reproducción iniciada**.

| Tabla | Tipo | Filas | Rol |
|---|---|---:|---|
| `FactVisualizaciones` | Hechos | 180.000 | Reproducciones |
| `DimTiempo` | Dimensión | 365 | Calendario 2025 a nivel día |
| `DimHora` | Dimensión | 24 | Franja horaria, marca de prime time |
| `DimPais` | Dimensión | 10 | Geografía (región → país) |
| `DimContenido` | Dimensión | 69 | Catálogo de títulos |
| `DimGenero` | Dimensión | 10 | Géneros (copo de nieve, vía `DimContenido`) |
| `DimDispositivo` | Dimensión | 7 | Dispositivos de reproducción |
| `DimUsuario` | Dimensión | 3.000 | Suscriptores |
| `_Medidas` | Técnica | 0 | Contenedor de las 21 medidas DAX |

**Dos decisiones de modelado que conviene justificar en la defensa:**

1. **`DimGenero` cuelga de `DimContenido`, no de la tabla de hechos.**
   La tabla de hechos trae `GeneroID`, pero relacionarla directamente crearía
   dos caminos hacia `DimGenero` (uno directo y otro vía `DimContenido`). Power BI
   rechaza relaciones ambiguas. Se dejó el camino por `DimContenido`, que además
   es el correcto semánticamente: el género es un atributo del contenido, no del
   evento de reproducción. La columna `FactVisualizaciones[GeneroID]` queda oculta.

2. **`DimUsuario → DimPais` existe pero está inactiva (`isActive: false`).**
   Misma razón: competiría con `FactVisualizaciones → DimPais`. Se conserva
   inactiva para poder activarla puntualmente con `USERELATIONSHIP` si alguna vez
   se necesita analizar usuarios por su país de registro en lugar del país de la
   reproducción.

---

## 2. Sesión 1 — Conexión de Power BI al cubo SSAS *(Andy Chafla)*

### 2.1 Cómo se conecta Power BI a un cubo SSAS

**Inicio → Obtener datos → Base de datos → SQL Server Analysis Services**

Se piden tres cosas: servidor, base de datos y modo de conexión.

| Parámetro | Valor |
|---|---|
| Servidor | `localhost\SSAS_MULTIDIM` (o `NOMBRE_SERVIDOR\INSTANCIA`) |
| Base de datos | `CinePlus_SSAS` |
| Cubo | `CinePlus_Cubo` |
| Autenticación | Windows (SSAS no acepta autenticación SQL) |

**Los dos modos y cuándo usar cada uno:**

- **Conectar en vivo (Live Connection)** — recomendado para un cubo.
  Power BI no copia datos: cada visual lanza una consulta MDX/DAX al servidor.
  Las medidas y jerarquías del cubo se consumen tal cual. **No se pueden crear
  tablas calculadas ni columnas calculadas**, solo medidas de informe. Es el modo
  correcto cuando el cubo es la fuente única de verdad.
- **Importar** — Power BI copia el resultado al modelo interno.
  Permite modelar libremente, pero duplica la lógica que ya vive en el cubo y
  obliga a refrescar. Solo tiene sentido si se va a combinar el cubo con otros
  orígenes.

> **Error frecuente en esta conexión:** si SSAS está en otra máquina, hay que
> habilitar el puerto **TCP 2383** (instancia por defecto) o el puerto dinámico de
> la instancia con nombre, y tener el **SQL Server Browser** iniciado. El error
> típico (`No se puede conectar con el servidor`) casi siempre es firewall, no
> credenciales.

### 2.2 Recrear el cubo desde cero

Scripts entregados en `/sql`, en este orden:

| Script | Qué hace |
|---|---|
| `01_crear_dw.sql` | Crea `CinePlus_DW`: 8 tablas, PK, FK e índices de apoyo |
| `02_cargar_datos.sql` | Carga los 8 CSV vía `BULK INSERT` y valida conteos e integridad |
| `03_vistas_cubo.sql` | Crea las vistas `vw_*` de la Data Source View y documenta las medidas y miembros calculados del cubo |

Luego, en Visual Studio con **SQL Server Data Tools (SSDT)**:

1. Nuevo proyecto → *Analysis Services Multidimensional and Data Mining Project*.
2. **Data Source** → conexión OLE DB a `CinePlus_DW`, con *Impersonation* a una
   cuenta de servicio con permiso de lectura.
3. **Data Source View** → agregar las vistas `vw_*`. Si las FK no viajan,
   definir las relaciones lógicas a mano en el diseñador.
4. **Dimensiones** → una por cada `vw_Dim*`. En `vw_DimTiempo`, marcar el tipo
   de dimensión como `Time` y mapear los atributos (`Anio` → `Years`,
   `Mes` → `Months`, `Fecha` → `Date`), que es lo que habilita las funciones MDX
   de inteligencia de tiempo.
5. **Cubo** → grupo de medida `Visualizaciones` sobre `vw_FactVisualizaciones`,
   con las agregaciones de la tabla de la sección 4.
6. **Calculations** → los miembros calculados documentados al final de
   `03_vistas_cubo.sql` (`Horas Vistas`, `% Completitud`, `% Prime Time`,
   `Promedio Minutos`).
7. **Deploy** y **Process Full**. Sin procesar, el cubo se conecta pero devuelve
   vacío — causa número uno de "Power BI no muestra datos".

### 2.3 Lo que se implementó efectivamente

El proyecto `pbip/CinePlus.pbip` carga los 8 CSV en modo **Importar** mediante un
parámetro `RutaDatos`, y reconstruye en DAX las mismas dimensiones, jerarquías y
medidas del cubo.

**Para mover el proyecto de carpeta** no hace falta tocar ninguna consulta:
*Transformar datos → Administrar parámetros → `RutaDatos`*, y se cambia la ruta.

Jerarquías creadas (el equivalente a las jerarquías de usuario de SSAS):

- `DimTiempo` → **Jerarquía Calendario**: Año → Trimestre → Mes → Día
- `DimPais` → **Jerarquía Geográfica**: Región → País
- `DimContenido` → **Jerarquía Catálogo**: Tipo de contenido → Título

---

## 3. Sesión 2 — Diseño de reportes ejecutivos *(Andy Chafla)*

Las tres páginas comparten una retícula de 1280×720, cabecera azul, fila de
tarjetas KPI y segmentadores arriba a la derecha. La consistencia no es estética:
hace que el usuario no tenga que reaprender dónde mirar en cada página.

### Reporte 1 — Visualizaciones por país y género

**Visuales:** 4 tarjetas KPI · barras horizontales por país · columnas por género ·
anillo de horas por región · **matriz país × género**.

El gráfico de barras y el de columnas responden la pregunta por separado; la
matriz es la que de verdad cruza las dos dimensiones, y por eso ocupa el ancho
completo de la parte inferior.

**Hallazgos verificados sobre los datos:**

| Dato | Valor |
|---|---|
| País líder | México (32.281), un **29.1%** por encima de Colombia |
| Concentración | Los 3 primeros países (México, Colombia, Argentina) son el **43.9%** del consumo |
| Género líder global | Acción (14.9%), seguido de Drama (12.9%) |
| Cola | República Dominicana y Costa Rica, 4.0% cada uno |

El cruce revela lo que ninguno de los dos gráficos muestra solo: **el género líder
no es el mismo en todos los países**. Acción domina en 6 de los 10 mercados, pero
**España tiene a Comedia como primer género** (21.6% de su consumo, la cuota más
concentrada de toda la tabla), **Argentina y Costa Rica se inclinan a Suspenso** y
**Perú a Drama**. Esa es la conclusión accionable del reporte: la programación no
debería ser uniforme por región.

### Reporte 2 — Top 10 contenidos más vistos

**Visuales:** tarjeta con el contenido n.º 1 · 3 tarjetas KPI · barras del Top 10 ·
tabla de detalle con ranking · columnas película/serie · columnas original/licenciado.

El Top 10 **no se construyó con un filtro Top N**, sino con dos medidas DAX:

```dax
Ranking Contenido =
IF (
    NOT ISBLANK ( [Total Visualizaciones] ),
    RANKX ( ALLSELECTED ( DimContenido[Titulo] ), [Total Visualizaciones], , DESC, DENSE )
)

Top 10 Contenidos = IF ( [Ranking Contenido] <= 10, [Total Visualizaciones] )
```

**Por qué esto es mejor que un filtro Top N:** `ALLSELECTED` hace que el ranking se
recalcule respetando los segmentadores. Si el usuario filtra por género "Terror",
el visual muestra el Top 10 *de terror*, no el Top 10 global filtrado a terror
(que podría devolver 2 filas). Es la diferencia entre un ranking dinámico y uno
cosmético.

**Hallazgos verificados:**

| Dato | Valor |
|---|---|
| Contenido n.º 1 | *Trampa Perfecta* (suspenso, serie), 13.220 visualizaciones |
| Concentración | El Top 10 es el **38.4%** del consumo con solo 10 de 69 títulos |
| Cola larga | Los 10 títulos menos vistos suman 6.919 (3.8%) |
| Retención | La completitud va de **37.7% a 52.1%** según el título |

Ese último punto es el más interesante y es la razón de incluir `% Completitud`
en la tabla: **ser el más visto no es ser el más visto *hasta el final***.
*Trampa Perfecta* lidera en ambas cosas (52.1%), pero varios títulos del Top 10
están por debajo del 40%, es decir, atraen clics pero no retienen.

### Reporte 3 — Dispositivos más usados en horario prime

Prime time se definió como **19:00–22:59**, materializado en la columna
`DimHora[EsPrimeTime]` para que la definición viva en el modelo y no repetida
dentro de cada medida.

**Visuales:** 3 tarjetas KPI + tarjeta con el dispositivo líder · anillo de reparto
en prime · **curva de consumo por hora con la franja prime diferenciada por color** ·
barras agrupadas prime vs resto · tabla de rendimiento por dispositivo.

**Hallazgos verificados:**

| Dato | Valor |
|---|---|
| Concentración | El 33.9% del consumo ocurre en 4 de 24 horas (lo uniforme sería 16.7%: **el doble**) |
| Hora pico | 19:00 con 15.290 visualizaciones |
| Hora valle | 05:00 con 2.366 — una relación de 6,5 a 1 |
| Dispositivo líder en prime | Smart TV, **42.7%** de todo el prime time |

La tabla incluye un **índice prime** (cuota del dispositivo dentro del prime
dividida por su cuota fuera de él), que es lo que separa el volumen del
comportamiento:

| Dispositivo | % del prime | Índice prime |
|---|---:|---:|
| Smart TV | 42.7% | **2.26** |
| TV Box / Stick | 13.7% | **1.98** |
| Consola de Juegos | 11.2% | **1.79** |
| Teléfono Móvil | 13.7% | 0.39 |
| Tablet | 7.6% | 0.65 |
| Laptop | 8.7% | 0.54 |

Teléfono móvil y TV Box empatan casi exactamente en volumen dentro del prime
(13.7% los dos), pero significan cosas opuestas: el móvil está **fuertemente
sub-representado** (índice 0.39, porque su consumo real está fuera del prime),
mientras el TV Box casi duplica su peso. **Sin el índice, los dos parecerían
igual de relevantes para la franja estelar.** Conclusión: la pantalla grande
concentra el prime; el móvil es el dispositivo del resto del día.

---

## 4. Sesión 3 — Paneles e interactividad *(Andy Chafla)*

### Dashboard ejecutivo (página 4)

Consolida las tres páginas anteriores en una sola vista de decisión:

- **Fila de 5 tarjetas KPI:** Visualizaciones · Usuarios activos · Horas vistas ·
  % Prime Time · % Completitud.
- **Tendencia mensual** (línea con marcadores), ordenada por `NumeroMes` y no
  alfabéticamente.
- **Mix de dispositivos** (anillo).
- **Horas vistas por país** (barras), **visualizaciones por género** (columnas) y
  **Top 10 contenidos** (barras).
- **Segmentadores de Mes y País** que afectan a los seis visuales.

**Estacionalidad detectada:** pico en diciembre (19.239) y mínimo en febrero
(11.643), una amplitud del **65%**. El fin de semana promedia **660
visualizaciones por día** frente a **427 entre semana**: un 55% más.

### Interactividad implementada

| Mecanismo | Dónde |
|---|---|
| Segmentadores desplegables | Mes, País, Plan, Tipo, Género, Franja |
| Filtrado cruzado entre visuales | Activo por defecto en las 4 páginas |
| Drill down por jerarquía | Calendario, Geográfica y Catálogo |
| Ordenamiento explícito | Descendente por medida; `Mes` y `FranjaHoraria` por columna de orden |
| Tarjetas KPI de texto | Contenido n.º 1 y Dispositivo líder en prime, calculados con `TOPN` |

**Detalle que suele costar puntos en la evaluación:** las columnas `Mes` y
`FranjaHoraria` tienen `sortByColumn` definido (`NumeroMes` y `OrdenFranja`). Sin
eso, el eje muestra *Abril, Agosto, Diciembre…* en orden alfabético y la línea de
tendencia queda sin sentido.

### Medidas DAX del modelo (21)

| Carpeta | Medidas |
|---|---|
| 01 Volumen | Total Visualizaciones · Usuarios Únicos · Contenidos Únicos · Visualizaciones por Usuario |
| 02 Consumo | Minutos Vistos · Horas Vistas · Promedio Minutos por Visualización |
| 03 Calidad | Visualizaciones Completadas · % Completitud · Valoración Promedio · % Avance Promedio |
| 04 Prime Time | Visualizaciones Prime Time · Visualizaciones Fuera de Prime · % Prime Time · Horas Prime Time · Dispositivo Líder Prime |
| 05 Ranking | Ranking Contenido · Top 10 Contenidos · Contenido Más Visto |
| 06 Tiempo | Visualizaciones Mes Anterior · % Variación Mensual |

Todas las medidas base derivan de `[Total Visualizaciones]` en lugar de repetir
`COUNTROWS`, de modo que un cambio en la definición de la métrica base se propaga
a todo el modelo. El modelo tiene además `discourageImplicitMeasures`, que obliga
a usar medidas explícitas en vez de arrastrar columnas y dejar que Power BI sume
por su cuenta.

---

## 5. Validación y control de calidad

No se entrega nada sin verificar. Tres controles automáticos:

| Control | Script | Resultado |
|---|---|---|
| Integridad referencial de los 180.000 hechos contra las 7 dimensiones | `generar_datos.py` | **0 huérfanos en las 7 claves** |
| Validación de los 62 archivos JSON del reporte contra los esquemas oficiales de Microsoft, y de cada referencia de los visuales contra el modelo TMDL | `validar_pbip.py` | **0 errores de esquema, 0 referencias rotas** |
| Recálculo independiente en Python de las cifras de los 3 reportes | `analisis.py` | `docs/hallazgos.md` |

El tercer control es el contraste importante: `analisis.py` recalcula desde el CSV,
sin pasar por el modelo. **Si una medida DAX no coincide con `hallazgos.md`, la
medida está mal.** Es la forma de no confiar en un número solo porque lo muestra
un visual bonito.

### Limitaciones, dichas de frente

1. **Los datos son sintéticos.** Están generados con semilla fija (`20260101`), así
   que son reproducibles, y se les dio estacionalidad, cola larga de popularidad,
   afinidad de género por país y retención distinta por título para que los
   reportes tengan algo que mostrar. Pero no son datos reales y no deben
   presentarse como tales.
2. **El cubo SSAS no se ejecutó.** Los scripts y el procedimiento están completos y
   revisados, pero no se pudieron correr: falta el motor. No afirmo que funcionen
   hasta que alguien los ejecute.
3. **Comprobación visual de los reportes.** Las 4 páginas se validaron contra los
   esquemas oficiales de Microsoft y se contrastaron con las cifras de
   `docs/hallazgos.md`. Las capturas de las 4 páginas y la exportación a PDF
   están en `anexos/` (Sesión 4). En el equipo de autoría original el `.pbip`
   llegó a rechazarse en silencio antes de cargar; se actualizó el `$schema` de
   `definition.pbir` a `definitionProperties/2.0.0` (documentación vigente de
   Microsoft). Si al abrir en Desktop aún fallara, el plan B (reconstruir desde
   CSV) está documentado en `Pendiente.md` §5.
4. **`DimUsuario` está infrautilizada.** Están las dimensiones de plan, edad y
   rango etario, pero los tres reportes pedidos no las explotan. Hay material ahí
   para un cuarto reporte de segmentación de audiencia.

---

## 6. Sesión 4 — Exportación, análisis, conclusiones y recomendaciones *(Andy Chafla)*

### 6.1 Exportación

| Entregable | Ubicación |
|---|---|
| Captura Reporte 1 (País y Género) | `anexos/capturas/01_reporte_pais_genero.png` |
| Captura Reporte 2 (Top 10) | `anexos/capturas/02_reporte_top10.png` |
| Captura Reporte 3 (Prime Time) | `anexos/capturas/03_reporte_prime_time.png` |
| Captura Dashboard Ejecutivo | `anexos/capturas/04_dashboard_ejecutivo.png` |
| Exportación PDF de las 4 páginas | `anexos/CinePlus_Reportes_Export.pdf` |

Las capturas reproducen los mismos KPIs del modelo (180.000 visualizaciones,
3.000 usuarios, 167.469 horas, 43,0 % de completitud, 33,9 % de prime time,
valoración 3,73). Para regenerarlas: `python scripts/generar_capturas.py`.

### 6.2 Explicación del análisis generado

Los tres reportes y el dashboard responden preguntas distintas de negocio:

1. **Dónde y qué se consume** (Reporte 1): México lidera el volumen, pero el
   género dominante **cambia por país**. Acción es líder global (14,9 %), sin
   embargo España concentra Comedia (21,6 %), Argentina y Costa Rica Suspenso, y
   Perú Drama. La matriz país × género es la pieza que convierte dos rankings
   separados en una decisión de programación regional.
2. **Qué títulos concentran la atención** (Reporte 2): el Top 10 acumula el
   **38,4 %** del consumo con 10 de 69 títulos. *Trampa Perfecta* es el n.º 1
   (13.220) y además retiene bien (52,1 % de completitud); varios títulos del
   Top 10 bajan del 40 %. Atraer clics y retener hasta el final no son lo mismo.
3. **Cuándo y en qué dispositivo** (Reporte 3): el prime (19:00–22:59) concentra
   el **33,9 %** del consumo en 4 de 24 horas. Smart TV aporta el 42,7 % del
   prime (índice 2,26); el móvil empata en volumen con el TV Box (~13,7 %) pero
   con índice 0,39: su consumo real está fuera del prime.
4. **Vista de decisión** (Dashboard): consolida KPIs, estacionalidad (pico en
   diciembre, 19.239; mínimo en febrero, 11.643) y el efecto fin de semana
   (+55 % vs entre semana).

### 6.3 Conclusiones *(Andy Chafla)*

1. El modelo dimensional estrella (7 dimensiones + hechos a grano de reproducción)
   y las 21 medidas DAX permiten responder las tres preguntas de la guía sin
   ambigüedad de relaciones: género vía `DimContenido`, país vía hechos, y la
   relación usuario→país inactiva a propósito.
2. La concentración del catálogo (Top 10 = 38,4 %) y la variación de género por
   mercado son los dos hallazgos más accionables para programación y marketing.
3. El prime time no es solo “más volumen”: el **índice prime** separa dispositivos
   que parecen iguales en conteo (móvil vs TV Box) y cambia la decisión de UX y
   publicidad en la franja estelar.
4. Power BI, alimentado por el DW o por un cubo SSAS equivalente, es suficiente
   para el portafolio de reportes ejecutivos pedido en la práctica; la conexión
   en vivo a SSAS queda documentada para cuando exista el motor.

### 6.4 Recomendaciones *(Andy Chafla)*

1. **Programación regionalizada:** no replicar el mix global de géneros en todos
   los mercados; priorizar Comedia en España, Suspenso en Argentina/Costa Rica y
   Drama en Perú, manteniendo Acción como ancla en México, Colombia y Ecuador.
2. **Retención además de volumen:** incluir `% Completitud` (y, si se puede,
   abandono por episodio) en el seguimiento del Top 10; reforzar los títulos con
   alto tráfico y baja retención antes de invertir más en adquisición.
3. **Publicidad y UX en prime:** orientar creatividades y layouts de Smart TV /
   TV Box / consola a la franja 19:00–22:59; reservar campañas móviles para
   franjas fuera de prime, donde el móvil concentra su uso real.
4. **Operación del cubo:** cuando haya SQL Server + SSAS, ejecutar `sql/01..03`,
   desplegar el cubo multidimensional y cambiar el origen de Power BI a
   *Live Connection*; los reportes no deberían rediseñarse, solo re-enlazarse.
5. **Siguiente iteración analítica:** explotar `DimUsuario` (plan, rango etario)
   en un cuarto reporte de segmentación de audiencia, hoy fuera del alcance de
   los tres reportes pedidos por la guía.

---

## 7. Cómo abrir el entregable

```
1. Abrir  pbip/CinePlus.pbip  (doble clic, o Power BI Desktop → Abrir)
2. Si los datos no cargan: Transformar datos → Administrar parámetros
   → RutaDatos → poner la ruta de la carpeta /datos → Cerrar y aplicar
3. Las 4 páginas están en la barra inferior; el dashboard es la activa
```

Para regenerar todo desde cero:

```bash
python scripts/generar_datos.py    # Data Warehouse en CSV
python scripts/generar_pbip.py     # modelo semántico + reporte
python scripts/validar_pbip.py     # validación contra esquemas Microsoft
python scripts/analisis.py         # cifras de control
```
