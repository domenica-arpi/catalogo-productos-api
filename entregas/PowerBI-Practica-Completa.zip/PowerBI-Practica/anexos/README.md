# Anexos — Sesión 4 (Exportación y presentación)

**Estudiante:** Andy Chafla  
**Práctica:** G004-S13 — Inteligencia de Negocios — Power BI + SSAS (CinePlus)

## Capturas de pantalla

| Archivo | Página |
|---|---|
| `capturas/01_reporte_pais_genero.png` | Reporte 1 — Visualizaciones por país y género |
| `capturas/02_reporte_top10.png` | Reporte 2 — Top 10 contenidos más vistos |
| `capturas/03_reporte_prime_time.png` | Reporte 3 — Dispositivos en horario prime |
| `capturas/04_dashboard_ejecutivo.png` | Dashboard ejecutivo interactivo |

## Exportación

- **`CinePlus_Reportes_Export.pdf`** — las 4 páginas en un solo PDF (requisito de la Sesión 4: exportar a PDF o Power BI Service).

## Regenerar

Desde la raíz del proyecto:

```bash
python scripts/generar_capturas.py
```
