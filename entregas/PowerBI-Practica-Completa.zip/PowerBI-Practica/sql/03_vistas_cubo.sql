/* ===================================================================
   CinePlus - Vistas para la Data Source View (DSV) del cubo SSAS
   Practica: Power BI + SSAS   |   Estudiante: Andy Chafla

   SSAS Multidimensional trabaja mejor sobre vistas con nombres
   "de negocio": permiten renombrar, calcular atributos y aislar
   el cubo de cambios en las tablas fisicas.

   Cada vista vw_Dim* alimenta una dimension del cubo CinePlus_Cubo;
   vw_FactVisualizaciones alimenta el grupo de medida [Visualizaciones].
   =================================================================== */

USE CinePlus_DW;
GO

IF OBJECT_ID('dbo.vw_DimPais', 'V')             IS NOT NULL DROP VIEW dbo.vw_DimPais;
IF OBJECT_ID('dbo.vw_DimGenero', 'V')           IS NOT NULL DROP VIEW dbo.vw_DimGenero;
IF OBJECT_ID('dbo.vw_DimDispositivo', 'V')      IS NOT NULL DROP VIEW dbo.vw_DimDispositivo;
IF OBJECT_ID('dbo.vw_DimContenido', 'V')        IS NOT NULL DROP VIEW dbo.vw_DimContenido;
IF OBJECT_ID('dbo.vw_DimUsuario', 'V')          IS NOT NULL DROP VIEW dbo.vw_DimUsuario;
IF OBJECT_ID('dbo.vw_DimTiempo', 'V')           IS NOT NULL DROP VIEW dbo.vw_DimTiempo;
IF OBJECT_ID('dbo.vw_DimHora', 'V')             IS NOT NULL DROP VIEW dbo.vw_DimHora;
IF OBJECT_ID('dbo.vw_FactVisualizaciones', 'V') IS NOT NULL DROP VIEW dbo.vw_FactVisualizaciones;
GO

CREATE VIEW dbo.vw_DimPais AS
SELECT  PaisID,
        Pais,
        CodigoISO,
        Region,
        Moneda,
        Region + ' - ' + Pais AS RegionPais   -- atributo de jerarquia
FROM    dbo.DimPais;
GO

CREATE VIEW dbo.vw_DimGenero AS
SELECT  GeneroID, Genero, CategoriaGenero
FROM    dbo.DimGenero;
GO

CREATE VIEW dbo.vw_DimDispositivo AS
SELECT  DispositivoID,
        Dispositivo,
        TipoDispositivo,
        SistemaOperativo,
        TamanoPantalla,
        CASE WHEN TamanoPantalla = 'Grande' THEN 'Sala'
             ELSE 'Personal' END AS ContextoUso
FROM    dbo.DimDispositivo;
GO

CREATE VIEW dbo.vw_DimContenido AS
SELECT  c.ContenidoID,
        c.Titulo,
        c.GeneroID,
        g.Genero,
        g.CategoriaGenero,
        c.TipoContenido,
        c.AnioEstreno,
        c.DuracionMin,
        c.Temporadas,
        c.Episodios,
        c.Clasificacion,
        c.OrigenContenido,
        CASE WHEN c.AnioEstreno >= YEAR(GETDATE()) - 2 THEN 'Reciente'
             WHEN c.AnioEstreno >= YEAR(GETDATE()) - 5 THEN 'Catalogo'
             ELSE 'Archivo' END AS AntiguedadContenido
FROM    dbo.DimContenido c
JOIN    dbo.DimGenero   g ON g.GeneroID = c.GeneroID;
GO

CREATE VIEW dbo.vw_DimUsuario AS
SELECT  u.UsuarioID,
        u.CodigoUsuario,
        u.PaisID,
        p.Pais,
        u.TipoPlan,
        u.Edad,
        u.RangoEtario,
        u.Genero,
        u.FechaRegistro,
        u.EstadoCuenta
FROM    dbo.DimUsuario u
JOIN    dbo.DimPais    p ON p.PaisID = u.PaisID;
GO

CREATE VIEW dbo.vw_DimTiempo AS
SELECT  FechaKey, Fecha, Anio, Trimestre, AnioTrimestre,
        NumeroMes, Mes, AnioMes, Dia, NombreDia, NumeroDia,
        SemanaAnio, TipoDia
FROM    dbo.DimTiempo;
GO

CREATE VIEW dbo.vw_DimHora AS
SELECT  HoraKey, Hora, FranjaHoraria, OrdenFranja,
        EsPrimeTime, PrimeTimeDesc, RangoHora
FROM    dbo.DimHora;
GO

/* La vista de hechos expone las medidas del cubo.
   MinutosVistos y Reproducciones son aditivas (SUM);
   Completado y EsPrimeTime se suman para derivar los porcentajes. */
CREATE VIEW dbo.vw_FactVisualizaciones AS
SELECT  VisualizacionID,
        FechaKey,
        HoraKey,
        UsuarioID,
        ContenidoID,
        DispositivoID,
        PaisID,
        GeneroID,
        MinutosVistos,
        PorcentajeVisto,
        CAST(Completado  AS INT) AS Completado,
        CAST(EsPrimeTime AS INT) AS EsPrimeTime,
        Reproducciones,
        Valoracion
FROM    dbo.FactVisualizaciones;
GO

PRINT 'Vistas de la DSV creadas.';
GO

/* ===================================================================
   MEDIDAS DEL CUBO CinePlus_Cubo
   -------------------------------------------------------------------
   Grupo de medida: [Visualizaciones]  (origen: vw_FactVisualizaciones)

     Medida                      Columna            Agregacion
     --------------------------  -----------------  ----------
     Total Visualizaciones       Reproducciones     Sum
     Minutos Vistos              MinutosVistos      Sum
     Visualizaciones Completadas Completado         Sum
     Visualizaciones Prime Time  EsPrimeTime        Sum
     Usuarios Unicos             UsuarioID          DistinctCount
     Contenidos Unicos           ContenidoID        DistinctCount
     Valoracion Promedio         Valoracion         AverageOfChildren

   Miembros calculados (pestana Calculations del cubo):

     CREATE MEMBER CURRENTCUBE.[Measures].[Horas Vistas] AS
         [Measures].[Minutos Vistos] / 60,
         FORMAT_STRING = '#,##0';

     CREATE MEMBER CURRENTCUBE.[Measures].[% Completitud] AS
         IIF([Measures].[Total Visualizaciones] = 0, NULL,
             [Measures].[Visualizaciones Completadas]
             / [Measures].[Total Visualizaciones]),
         FORMAT_STRING = 'Percent';

     CREATE MEMBER CURRENTCUBE.[Measures].[% Prime Time] AS
         IIF([Measures].[Total Visualizaciones] = 0, NULL,
             [Measures].[Visualizaciones Prime Time]
             / [Measures].[Total Visualizaciones]),
         FORMAT_STRING = 'Percent';

     CREATE MEMBER CURRENTCUBE.[Measures].[Promedio Minutos] AS
         IIF([Measures].[Total Visualizaciones] = 0, NULL,
             [Measures].[Minutos Vistos]
             / [Measures].[Total Visualizaciones]),
         FORMAT_STRING = '#,##0.0';
   =================================================================== */
