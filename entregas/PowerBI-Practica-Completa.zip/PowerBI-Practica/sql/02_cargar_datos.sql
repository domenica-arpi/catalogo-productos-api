/* ===================================================================
   CinePlus - Carga del Data Warehouse desde los CSV generados
   Practica: Power BI + SSAS   |   Estudiante: Andy Chafla

   IMPORTANTE
   ----------
   BULK INSERT lee los archivos desde el SERVIDOR, no desde el cliente.
   Si SQL Server corre en otra maquina, copia la carpeta /datos al
   servidor y ajusta la variable @ruta.

   Los CSV estan en UTF-8 con BOM y delimitados por punto y coma (;).
   CODEPAGE = '65001' es obligatorio para que las tildes y la enie
   se carguen correctamente.
   =================================================================== */

USE CinePlus_DW;
GO

SET NOCOUNT ON;

/* Ajusta esta ruta a la ubicacion real de la carpeta /datos */
DECLARE @ruta NVARCHAR(400) = N'C:\Users\achafla\Desktop\PowerBI-Practica\datos\';
DECLARE @sql  NVARCHAR(MAX);

/* Vaciado en orden inverso a las dependencias */
DELETE FROM dbo.FactVisualizaciones;
DELETE FROM dbo.DimContenido;
DELETE FROM dbo.DimUsuario;
DELETE FROM dbo.DimGenero;
DELETE FROM dbo.DimPais;
DELETE FROM dbo.DimDispositivo;
DELETE FROM dbo.DimTiempo;
DELETE FROM dbo.DimHora;

/* -------------------------------------------------------------------
   Carga generica. FIRSTROW = 2 salta la fila de encabezados.
   ------------------------------------------------------------------- */
DECLARE @tablas TABLE (orden INT, tabla SYSNAME);
INSERT INTO @tablas (orden, tabla) VALUES
    (1, 'DimPais'), (2, 'DimGenero'), (3, 'DimDispositivo'), (4, 'DimContenido'),
    (5, 'DimUsuario'), (6, 'DimTiempo'), (7, 'DimHora'), (8, 'FactVisualizaciones');

DECLARE @t SYSNAME, @o INT = 0;

WHILE 1 = 1
BEGIN
    SELECT TOP 1 @t = tabla, @o = orden
    FROM @tablas WHERE orden > @o ORDER BY orden;

    IF @@ROWCOUNT = 0 BREAK;

    SET @sql = N'
        BULK INSERT dbo.' + QUOTENAME(@t) + N'
        FROM ''' + @ruta + @t + N'.csv''
        WITH (
            FIRSTROW        = 2,
            FIELDTERMINATOR = '';'',
            ROWTERMINATOR   = ''0x0a'',
            CODEPAGE        = ''65001'',
            TABLOCK,
            KEEPNULLS
        );';

    BEGIN TRY
        EXEC sp_executesql @sql;
        PRINT '  Cargada: ' + @t;
    END TRY
    BEGIN CATCH
        PRINT '  ERROR en ' + @t + ': ' + ERROR_MESSAGE();
    END CATCH
END
GO

/* ===================================================================
   VALIDACION POST-CARGA
   Estas cifras deben coincidir con las que imprime generar_datos.py
   =================================================================== */
PRINT '';
PRINT '--- Conteo de filas ---';

SELECT 'DimPais' AS Tabla, COUNT(*) AS Filas, 10 AS Esperado FROM dbo.DimPais
UNION ALL SELECT 'DimGenero',       COUNT(*),     10 FROM dbo.DimGenero
UNION ALL SELECT 'DimDispositivo',  COUNT(*),      7 FROM dbo.DimDispositivo
UNION ALL SELECT 'DimContenido',    COUNT(*),     69 FROM dbo.DimContenido
UNION ALL SELECT 'DimUsuario',      COUNT(*),   3000 FROM dbo.DimUsuario
UNION ALL SELECT 'DimTiempo',       COUNT(*),    365 FROM dbo.DimTiempo
UNION ALL SELECT 'DimHora',         COUNT(*),     24 FROM dbo.DimHora
UNION ALL SELECT 'FactVisualizaciones', COUNT(*), 180000 FROM dbo.FactVisualizaciones;

PRINT '';
PRINT '--- Indicadores de control ---';

SELECT
    COUNT(*)                                            AS TotalVisualizaciones,
    COUNT(DISTINCT UsuarioID)                           AS UsuariosUnicos,
    SUM(CAST(MinutosVistos AS BIGINT))                  AS MinutosVistos,
    SUM(CAST(MinutosVistos AS BIGINT)) / 60             AS HorasVistas,
    CAST(100.0 * SUM(CAST(EsPrimeTime AS INT)) / COUNT(*) AS DECIMAL(5,1)) AS PctPrimeTime,
    CAST(100.0 * SUM(CAST(Completado  AS INT)) / COUNT(*) AS DECIMAL(5,1)) AS PctCompletitud
FROM dbo.FactVisualizaciones;

PRINT '';
PRINT '--- Integridad referencial (todo debe dar 0) ---';

SELECT 'Fecha huerfana' AS Verificacion, COUNT(*) AS Filas
FROM dbo.FactVisualizaciones f
LEFT JOIN dbo.DimTiempo d ON d.FechaKey = f.FechaKey WHERE d.FechaKey IS NULL
UNION ALL
SELECT 'Contenido huerfano', COUNT(*)
FROM dbo.FactVisualizaciones f
LEFT JOIN dbo.DimContenido d ON d.ContenidoID = f.ContenidoID WHERE d.ContenidoID IS NULL
UNION ALL
SELECT 'Usuario huerfano', COUNT(*)
FROM dbo.FactVisualizaciones f
LEFT JOIN dbo.DimUsuario d ON d.UsuarioID = f.UsuarioID WHERE d.UsuarioID IS NULL;

PRINT '';
PRINT 'Carga finalizada.';
GO
