/* ===================================================================
   CinePlus - Data Warehouse (esquema estrella)
   Motor   : SQL Server 2019+ (Developer / Express)
   Practica: Power BI + SSAS   |   Estudiante: Andy Chafla

   Este script crea la base de datos relacional que sirve de origen
   (Data Source) al cubo multidimensional CinePlus_Cubo en SSAS.

   Orden de ejecucion:
     01_crear_dw.sql     <- estructura
     02_cargar_datos.sql <- carga desde los CSV de /datos
     03_vistas_cubo.sql  <- vistas para la Data Source View del cubo
   =================================================================== */

IF DB_ID('CinePlus_DW') IS NULL
    CREATE DATABASE CinePlus_DW;
GO

USE CinePlus_DW;
GO

/* ------------------------------------------------------------------
   Limpieza: la tabla de hechos primero por las claves foraneas
   ------------------------------------------------------------------ */
IF OBJECT_ID('dbo.FactVisualizaciones', 'U') IS NOT NULL DROP TABLE dbo.FactVisualizaciones;
IF OBJECT_ID('dbo.DimContenido',    'U') IS NOT NULL DROP TABLE dbo.DimContenido;
IF OBJECT_ID('dbo.DimUsuario',      'U') IS NOT NULL DROP TABLE dbo.DimUsuario;
IF OBJECT_ID('dbo.DimGenero',       'U') IS NOT NULL DROP TABLE dbo.DimGenero;
IF OBJECT_ID('dbo.DimPais',         'U') IS NOT NULL DROP TABLE dbo.DimPais;
IF OBJECT_ID('dbo.DimDispositivo',  'U') IS NOT NULL DROP TABLE dbo.DimDispositivo;
IF OBJECT_ID('dbo.DimTiempo',       'U') IS NOT NULL DROP TABLE dbo.DimTiempo;
IF OBJECT_ID('dbo.DimHora',         'U') IS NOT NULL DROP TABLE dbo.DimHora;
GO

/* =================================================================
   DIMENSIONES
   ================================================================= */

CREATE TABLE dbo.DimPais (
    PaisID      INT          NOT NULL,
    Pais        NVARCHAR(60) NOT NULL,
    CodigoISO   NCHAR(2)     NOT NULL,
    Region      NVARCHAR(40) NOT NULL,
    Moneda      NCHAR(3)     NOT NULL,
    CONSTRAINT PK_DimPais PRIMARY KEY CLUSTERED (PaisID)
);
GO

CREATE TABLE dbo.DimGenero (
    GeneroID        INT          NOT NULL,
    Genero          NVARCHAR(40) NOT NULL,
    CategoriaGenero NVARCHAR(40) NOT NULL,
    CONSTRAINT PK_DimGenero PRIMARY KEY CLUSTERED (GeneroID)
);
GO

CREATE TABLE dbo.DimDispositivo (
    DispositivoID    INT          NOT NULL,
    Dispositivo      NVARCHAR(50) NOT NULL,
    TipoDispositivo  NVARCHAR(30) NOT NULL,
    SistemaOperativo NVARCHAR(40) NOT NULL,
    TamanoPantalla   NVARCHAR(20) NOT NULL,
    CONSTRAINT PK_DimDispositivo PRIMARY KEY CLUSTERED (DispositivoID)
);
GO

CREATE TABLE dbo.DimContenido (
    ContenidoID     INT           NOT NULL,
    Titulo          NVARCHAR(120) NOT NULL,
    GeneroID        INT           NOT NULL,
    TipoContenido   NVARCHAR(20)  NOT NULL,
    AnioEstreno     SMALLINT      NOT NULL,
    DuracionMin     INT           NOT NULL,
    Temporadas      TINYINT       NOT NULL,
    Episodios       SMALLINT      NOT NULL,
    Clasificacion   NVARCHAR(10)  NOT NULL,
    OrigenContenido NVARCHAR(30)  NOT NULL,
    CONSTRAINT PK_DimContenido PRIMARY KEY CLUSTERED (ContenidoID),
    CONSTRAINT FK_DimContenido_Genero FOREIGN KEY (GeneroID)
        REFERENCES dbo.DimGenero (GeneroID)
);
GO

CREATE TABLE dbo.DimUsuario (
    UsuarioID     INT          NOT NULL,
    CodigoUsuario NVARCHAR(20) NOT NULL,
    PaisID        INT          NOT NULL,
    TipoPlan      NVARCHAR(20) NOT NULL,
    Edad          TINYINT      NOT NULL,
    RangoEtario   NVARCHAR(10) NOT NULL,
    Genero        NVARCHAR(20) NOT NULL,
    FechaRegistro DATE         NOT NULL,
    EstadoCuenta  NVARCHAR(20) NOT NULL,
    CONSTRAINT PK_DimUsuario PRIMARY KEY CLUSTERED (UsuarioID),
    CONSTRAINT FK_DimUsuario_Pais FOREIGN KEY (PaisID)
        REFERENCES dbo.DimPais (PaisID)
);
GO

CREATE TABLE dbo.DimTiempo (
    FechaKey      INT          NOT NULL,   -- AAAAMMDD
    Fecha         DATE         NOT NULL,
    Anio          SMALLINT     NOT NULL,
    Trimestre     NVARCHAR(4)  NOT NULL,
    AnioTrimestre NVARCHAR(10) NOT NULL,
    NumeroMes     TINYINT      NOT NULL,
    Mes           NVARCHAR(20) NOT NULL,
    AnioMes       NVARCHAR(10) NOT NULL,
    Dia           TINYINT      NOT NULL,
    NombreDia     NVARCHAR(20) NOT NULL,
    NumeroDia     TINYINT      NOT NULL,
    SemanaAnio    TINYINT      NOT NULL,
    TipoDia       NVARCHAR(20) NOT NULL,
    CONSTRAINT PK_DimTiempo PRIMARY KEY CLUSTERED (FechaKey)
);
GO

CREATE TABLE dbo.DimHora (
    HoraKey       TINYINT      NOT NULL,   -- 0 a 23
    Hora          NCHAR(5)     NOT NULL,
    FranjaHoraria NVARCHAR(20) NOT NULL,
    OrdenFranja   TINYINT      NOT NULL,
    EsPrimeTime   BIT          NOT NULL,
    PrimeTimeDesc NVARCHAR(5)  NOT NULL,
    RangoHora     NVARCHAR(20) NOT NULL,
    CONSTRAINT PK_DimHora PRIMARY KEY CLUSTERED (HoraKey)
);
GO

/* =================================================================
   TABLA DE HECHOS
   Grano: una fila por reproduccion iniciada.
   ================================================================= */

CREATE TABLE dbo.FactVisualizaciones (
    VisualizacionID INT          NOT NULL,
    FechaKey        INT          NOT NULL,
    HoraKey         TINYINT      NOT NULL,
    UsuarioID       INT          NOT NULL,
    ContenidoID     INT          NOT NULL,
    DispositivoID   INT          NOT NULL,
    PaisID          INT          NOT NULL,
    GeneroID        INT          NOT NULL,
    MinutosVistos   INT          NOT NULL,
    PorcentajeVisto DECIMAL(5,2) NOT NULL,
    Completado      BIT          NOT NULL,
    EsPrimeTime     BIT          NOT NULL,
    Reproducciones  INT          NOT NULL,
    Valoracion      TINYINT      NULL,      -- solo ~22% de las sesiones califica
    CONSTRAINT PK_FactVisualizaciones PRIMARY KEY CLUSTERED (VisualizacionID),
    CONSTRAINT FK_Fact_Tiempo      FOREIGN KEY (FechaKey)      REFERENCES dbo.DimTiempo (FechaKey),
    CONSTRAINT FK_Fact_Hora        FOREIGN KEY (HoraKey)       REFERENCES dbo.DimHora (HoraKey),
    CONSTRAINT FK_Fact_Usuario     FOREIGN KEY (UsuarioID)     REFERENCES dbo.DimUsuario (UsuarioID),
    CONSTRAINT FK_Fact_Contenido   FOREIGN KEY (ContenidoID)   REFERENCES dbo.DimContenido (ContenidoID),
    CONSTRAINT FK_Fact_Dispositivo FOREIGN KEY (DispositivoID) REFERENCES dbo.DimDispositivo (DispositivoID),
    CONSTRAINT FK_Fact_Pais        FOREIGN KEY (PaisID)        REFERENCES dbo.DimPais (PaisID),
    CONSTRAINT FK_Fact_Genero      FOREIGN KEY (GeneroID)      REFERENCES dbo.DimGenero (GeneroID)
);
GO

/* Indices de apoyo: SSAS recorre la tabla de hechos por cada clave
   de dimension al procesar las particiones. */
CREATE NONCLUSTERED INDEX IX_Fact_Fecha       ON dbo.FactVisualizaciones (FechaKey)      INCLUDE (MinutosVistos, Completado);
CREATE NONCLUSTERED INDEX IX_Fact_Hora        ON dbo.FactVisualizaciones (HoraKey)       INCLUDE (MinutosVistos, EsPrimeTime);
CREATE NONCLUSTERED INDEX IX_Fact_Contenido   ON dbo.FactVisualizaciones (ContenidoID)   INCLUDE (MinutosVistos);
CREATE NONCLUSTERED INDEX IX_Fact_Pais        ON dbo.FactVisualizaciones (PaisID)        INCLUDE (MinutosVistos);
CREATE NONCLUSTERED INDEX IX_Fact_Dispositivo ON dbo.FactVisualizaciones (DispositivoID) INCLUDE (MinutosVistos, EsPrimeTime);
GO

PRINT 'CinePlus_DW: estructura creada correctamente.';
GO
