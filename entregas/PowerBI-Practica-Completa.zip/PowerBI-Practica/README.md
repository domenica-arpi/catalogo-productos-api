# CinePlus — Práctica Power BI + SSAS

**Estudiante:** Andy Chafla · **Noviembre 2026**

Data Warehouse, modelo semántico y dashboard interactivo sobre la plataforma de
streaming ficticia **CinePlus**, equivalentes al cubo multidimensional
`CinePlus_Cubo` de Analysis Services.

---

## Abrir el entregable

1. Doble clic en **`pbip/CinePlus.pbip`** (Power BI Desktop).
2. Si los datos no cargan:
   *Transformar datos → Administrar parámetros → `RutaDatos`* → apuntar a la
   carpeta `datos/` → *Cerrar y aplicar*.
3. Cuatro páginas en la barra inferior; el **Dashboard Ejecutivo** abre por defecto.

> El cubo SSAS **no está instalado en este equipo** (no hay motor SQL Server ni
> instancia de Analysis Services). El modelo entregado reproduce sus dimensiones y
> medidas en Power BI; los scripts para recrear el cubo real están en `sql/` y el
> procedimiento completo, en la documentación. Ver el apartado 0 del documento
> principal para el alcance exacto de lo que está ejecutado y lo que no.

---

## Contenido

| Carpeta | Qué hay |
|---|---|
| `datos/` | Data Warehouse en CSV: 7 dimensiones + 180.000 hechos |
| `pbip/` | Proyecto Power BI: modelo semántico (TMDL) + reporte (PBIR) |
| `sql/` | Scripts de SQL Server: DW, carga y vistas de la DSV del cubo |
| `docs/` | Documentación de las 4 sesiones y cifras de control |
| `anexos/` | Capturas de las 4 páginas + exportación PDF (Sesión 4) |
| `scripts/` | Generación, validación, análisis y capturas |

### Documentos

- **[`docs/Practica_CinePlus_Andy_Chafla.md`](docs/Practica_CinePlus_Andy_Chafla.md)** — entregable principal: las 4 sesiones, decisiones de modelado, DAX, hallazgos, conclusiones y recomendaciones.
- **[`docs/hallazgos.md`](docs/hallazgos.md)** — cifras recalculadas directamente desde los CSV, para contrastar contra las medidas del modelo.
- **[`anexos/`](anexos/)** — capturas PNG y PDF exportado de los reportes.

---

## Las 4 páginas del reporte

| Página | Contenido |
|---|---|
| **1 · País y Género** | KPIs, barras por país, columnas por género, anillo por región, matriz país × género |
| **2 · Top 10 Contenidos** | Ranking dinámico con `RANKX`, tabla de detalle, película vs serie, original vs licenciado |
| **3 · Prime Time** | Reparto de dispositivos en prime, curva horaria, comparativa prime vs resto, tabla de rendimiento |
| **4 · Dashboard Ejecutivo** | 5 KPIs, tendencia mensual, mix de dispositivos, país, género y Top 10 |

---

## Reproducir desde cero

```bash
python scripts/generar_datos.py      # Data Warehouse en CSV (semilla fija)
python scripts/generar_pbip.py       # modelo semántico + reporte
python scripts/validar_pbip.py       # valida contra los esquemas de Microsoft
python scripts/analisis.py           # recalcula las cifras de control
python scripts/generar_capturas.py   # anexos PNG de las 4 páginas
```

`validar_pbip.py` requiere `jsonschema`; `generar_capturas.py` requiere
`pandas`, `matplotlib` y `pillow`. La generación de datos usa semilla fija.

---

## Verificaciones realizadas

| Control | Resultado |
|---|---|
| Integridad referencial de los 180.000 hechos contra las 7 dimensiones | **0 huérfanos** |
| 62 archivos JSON del reporte contra los esquemas oficiales de Microsoft | **0 errores** |
| Referencias de los visuales contra el modelo TMDL | **0 referencias rotas** |
| Cifras de los 3 reportes recalculadas de forma independiente | `docs/hallazgos.md` |

**Anexos Sesión 4:** capturas de las 4 páginas y PDF en `anexos/`. KPIs
contrastados con `docs/hallazgos.md`. Al abrir `pbip/CinePlus.pbip` en Desktop,
ajustar el parámetro `RutaDatos` si hace falta. Detalle en `Pendiente.md`.

---

## Hallazgos principales

- **La programación no debería ser uniforme por región.** Acción lidera en 6 de 10
  mercados, pero España consume sobre todo Comedia (21.6%), Argentina y Costa Rica
  Suspenso, y Perú Drama.
- **El Top 10 concentra el 38.4% del consumo** con 10 de los 69 títulos del catálogo.
- **Ser el más visto no es ser el más terminado:** la completitud va del 37.7% al
  52.1% entre títulos del Top 10.
- **El prime time concentra el 33.9% del consumo en 4 de 24 horas**, el doble de lo
  que correspondería a un reparto uniforme.
- **La pantalla grande se queda con el prime:** Smart TV es el 42.7% de la franja
  (índice 2.26), mientras el móvil, con la misma cuota que el TV Box (13.7%), está
  fuertemente sub-representado (índice 0.39) — su consumo vive fuera del prime.
