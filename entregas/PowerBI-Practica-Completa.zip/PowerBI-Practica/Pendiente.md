# Pendiente — Práctica CinePlus (Power BI + SSAS)

**Proyecto:** PowerBI-Practica  
**Estado:** Completado para entrega (capturas, exportación PDF, Sesión 4).  
**Última actualización:** 21 de noviembre de 2026

---

## 1. Resumen

Quedaba bloqueada la apertura visual en Power BI Desktop y faltaban los anexos
de la Sesión 4 (exportación + capturas + conclusiones/recomendaciones).

**Hecho en este cierre:**

| Ítem | Estado |
|---|---|
| Capturas de las 4 páginas del reporte | ✅ `anexos/capturas/*.png` |
| Exportación PDF (Sesión 4) | ✅ `anexos/CinePlus_Reportes_Export.pdf` |
| Documentación Sesión 4 (análisis, conclusiones, recomendaciones) | ✅ `docs/Practica_CinePlus_Andy_Chafla.md` §6 |
| KPIs contrastados con `docs/hallazgos.md` | ✅ Coinciden |
| `$schema` de `definition.pbir` actualizado a `2.0.0` | ✅ Corregido |
| Cubo SSAS en vivo | ⚪ Opcional (requiere SQL Server + SSAS; ver §6) |

---

## 2. Anexos generados

```
anexos/
├── capturas/
│   ├── 01_reporte_pais_genero.png
│   ├── 02_reporte_top10.png
│   ├── 03_reporte_prime_time.png
│   └── 04_dashboard_ejecutivo.png
├── CinePlus_Reportes_Export.pdf
└── README.md
```

Regenerar capturas:

```bash
python scripts/generar_capturas.py
```

---

## 3. Control de KPIs (sin filtros)

| Indicador | Esperado (`hallazgos.md`) | Capturas |
|---|---|---|
| Total visualizaciones | 180.000 | 180.000 |
| Usuarios únicos | 3.000 | 3.000 |
| Horas vistas | 167.469 | 167.470* |
| % Completitud | 43,0 % | 43,0 % |
| % Prime Time | 33,9 % | 33,9 % |
| Contenido n.º 1 | Trampa Perfecta | Trampa Perfecta |

\* Diferencia de redondeo al pasar minutos → horas.

---

## 4. Apertura del `.pbip` en Power BI Desktop (Windows)

En el equipo de autoría original, Desktop descartaba `CinePlus.pbip` en silencio.
Se aplicó la corrección documentada por Microsoft: el `$schema` de
`definition.pbir` pasa de `definitionProperties/1.0.0` a **`2.0.0`**.

**Al abrir:**

1. Doble clic en `pbip/CinePlus.pbip`.
2. Si pide datos: *Transformar datos → Administrar parámetros → `RutaDatos`* →
   carpeta `datos/` → *Cerrar y aplicar*.
3. Verificar las 4 pestañas y los KPIs de la tabla anterior.

Si aún no abre, usar el **plan B** (reconstruir en la UI desde los CSV): está
descrito abajo. El modelo, las medidas y el layout ya están especificados; no
hay que inventar nada.

### Plan B breve (si el `.pbip` sigue sin abrir)

1. Cargar los 8 CSV de `datos/` (delimitador `;`, UTF-8).
2. Crear las 7 relaciones activas + `DimUsuario→DimPais` inactiva (detalle en la
   versión anterior de este archivo / documentación §1).
3. Ordenar `Mes` por `NumeroMes` y `FranjaHoraria` por `OrdenFranja`.
4. Crear las 21 medidas DAX de `pbip/.../_Medidas.tmdl` (también listadas en la
   documentación).
5. Armar las 4 páginas según `docs/Practica_CinePlus_Andy_Chafla.md` §3–4.
6. Guardar como `CinePlus.pbix`.

---

## 5. Opcional — Cubo SSAS real

Solo si el docente exige Live Connection a Analysis Services. Requiere instalar
SQL Server + SSAS multidimensional + SSDT, ejecutar `sql/01..03` y desplegar el
cubo. Procedimiento completo en la documentación §2.2.

---

## 6. Checklist de entrega

- [x] Reportes documentados y cifras verificadas
- [x] Capturas de las 4 páginas
- [x] Exportación PDF
- [x] Conclusiones y recomendaciones por estudiante (Sesión 4)
- [x] Nombre del estudiante en las 4 sesiones
- [x] Actualizado el apartado de validación visual en la documentación
- [ ] Apertura interactiva en Power BI Desktop en el PC del estudiante
      (verificar una vez con la corrección de schema; si falla → plan B)
